﻿using OpenQA.Selenium;
using NUnit.Framework;
using Service_Portal.Helper;

namespace DataHub.Pages
{
    internal class HomePage
    {
        private IWebDriver driver;
        public HomePage(IWebDriver driver) => this.driver = driver;

       
        protected By dataHubTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Data Hub')]");
        protected By workQueuesTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Work Queues')]");
        protected By searchTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Search')]");
        protected By integrationTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Integrations')]");
        protected By reportsTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Reports')]");
        protected By settingsTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Settings')]");
        //Work Queues
        protected By entityStewardShipTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Entity Stewardship')]");
        protected By _3PStewardShipTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), '3P Stewardship')]");
        //Integration
        protected By exportDataTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Export Data')]");
        protected By importDataTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Import Data')]");
        //Reports
        protected By caseMgmtTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Case Management')]");
        protected By stewardshipTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Stewardship Metrics')]");
        //Portal
        protected By portalTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Portal')]");
        
        //Pages Validation
        protected By dataHubHeader = By.XPath("//header//*[contains(text(), 'Data Hub')]");
        protected By importDataHeader = By.XPath("//header//*[contains(text(),'Import Data Status')]");
        protected By exportDataHeader = By.XPath("//*[contains(text(),'Export Data ')]");
        protected By powerBiReportTable = By.XPath("//iframe[contains(@src,'https://app.powerbi.com')]");
        protected By searchDataHubHeader = By.XPath("//header//*[contains(text(), 'Search Data Hub')]");
        protected By entityStewardshipHeader = By.XPath("//header//*[contains(text(), 'Entity Stewardship')]");
        protected By matchDataHeader = By.XPath("//header//*[contains(text(), 'Match Data')]");

        public HomePage ValidationOfEachTab()
        {
            {
                bool Flag = false;
                By[] Tabs = new By[] { searchTab,reportsTab,integrationTab,settingsTab,workQueuesTab,dataHubTab };
                foreach (By tabName in Tabs)
                {
                    Assert.IsTrue(HelperActions.ElementExists(tabName, driver),"Failed in validating the HomePage Tabs");

                }
                return new HomePage(driver);
            }
        }
        public HomePage ClickingTab(String TabName)
        {
            var tabname = By.XPath("//*");
            if (TabName.ToUpper().Contains("DATA HUB"))
            {
                tabname = dataHubTab;
            }
            if (TabName.ToUpper().Contains("WORK QUEUES"))
            {
                tabname = workQueuesTab;
            }
            if (TabName.ToUpper().Contains("SEARCH"))
            {
                tabname = searchTab;
            }
            if (TabName.ToUpper().Contains("INTEGRATIONS"))
            {
                tabname = integrationTab;
            }
            if (TabName.ToUpper().Contains("REPORTS"))
            {
                tabname = reportsTab;
            }
            if (TabName.ToUpper().Contains("SETTING"))
            {
                tabname = settingsTab;
            }
            HelperActions.OnClick(tabname, driver);
            return new HomePage(driver);

        }
        public SettingsPage SelectingSettingSubTab(string TabName)
        {
            By subtabname = By.XPath("");
            if (TabName.ToUpper().Contains("PORTAL"))
                subtabname = portalTab;
                HelperActions.OnClick(subtabname, driver);
            return new SettingsPage(driver);
        }
        public ReportsPage SelectingReportsSubTab(string TabName)
        {
            By verifyPage = By.XPath("");
            By subtabname = By.XPath("");
            if (TabName.ToUpper().Contains("CASE MANAGEMENT"))

                subtabname = caseMgmtTab;
            else if (TabName.ToUpper().Contains("STEWARDSHIP METRICS"))
            {
                subtabname = stewardshipTab;
                verifyPage = powerBiReportTable;
            }
            else
                Console.WriteLine("Wrong input");
            HelperActions.OnClick(subtabname, driver);
            Assert.IsTrue(HelperActions.ElementExists(verifyPage, driver),"failed in Valiting Reporting Subtab landing pages");
            return new ReportsPage(driver);
        }
        public IntegrationsPage SelectingIntegrationSubTab(string TabName)
        {
            By subtabname = By.XPath("");
            By verifyPage = By.XPath("");
            if (TabName.ToUpper().Contains("IMPORT DATA"))
            {
                subtabname = importDataTab;
                verifyPage = importDataHeader;
            }
            else if (TabName.ToUpper().Contains("EXPORT DATA"))
            {
                subtabname = exportDataTab;
                verifyPage = exportDataHeader;
            }
            else
                Console.WriteLine("Wrong input");
            HelperActions.OnClick(subtabname, driver);
            Assert.IsTrue(HelperActions.ElementExists (verifyPage, driver),"Failed in Validating integration subtab landing pages");   
            return new IntegrationsPage(driver);
        }
        public WorkQueuesPage SelectingWorkQueuesSubTab(string TabName)
        {
            By verifyPage = By.XPath("");
            By subtabname = By.XPath("");
            if (TabName.ToUpper().Contains("ENTITY STEWARDSHIP"))
            {
                subtabname = entityStewardShipTab;
                verifyPage = entityStewardshipHeader;
                    }
            else if (TabName.ToUpper().Contains("3P STEWARDSHIP"))
            {
                subtabname = _3PStewardShipTab;
                verifyPage = matchDataHeader;
            }
            else
                Console.WriteLine("Wrong input");
            HelperActions.OnClick(subtabname, driver);
            Assert.IsTrue(HelperActions.ElementExists(verifyPage, driver),"failed in validating work queue subtab landing pages");
            return new WorkQueuesPage(driver);
        }

    }
}
