﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using Service_Portal.Helper;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataHub.Pages
{
    internal class WorkQueuesPage
    {
        private IWebDriver driver;
        //private HomePage homePage;
        public WorkQueuesPage(IWebDriver driver) => this.driver = driver;
        protected By importDataFinishBtn = By.Id("ComfirmDetailsFinish");
        //protected By closeFiltersEntityStewardship= By.XPath("//*[@class='FilterContainer']/div[contains(@id,'filter')]//div[@class='close_button']/a[@class='removeFilter']");
        protected By closeFiltersEntityStewardship= By.XPath(" //*[@class='FilterContainer']/div[contains(@id,'filter')]//span[@class='close_button']");
        protected By entityStewardShipStatusFilterBtn = By.Id("divFilterInfo0");
        protected By entityStewardShipSourceFilterBtn = By.Id("filterColumn2");
        protected By addFilterToEntityStewardShipBtn = By.Id("btnAddFilter");
        protected By filteredValuetoSourceId = By.XPath("//input[@id='filterValSrcRecordId2']");
        protected By filteredValuetoImportProcessDropDwn = By.XPath(" //*[@id='divmsImportProcessId2']//*[@class='multiselect dropdown-toggle filterDDbtn']");
        protected By searchImportProcessTxtbx = By.XPath("//*[@id='divmsImportProcessId2']//*[@class='form-control multiselect-search']");
        protected By statusDropDwnFilter= By.XPath("//*[@class='multiselect-container dropdown-menu show']//label[@class='radio']");
        protected By entityStewardShipFilterDropDwn = By.XPath("//*[@id='filterValStatus0'][@name='filterValStatus0']");
        protected By entityStewardShipStatusFiterSrcRecordIfTxtBx = By.Id("divFilterValue2");

        public WorkQueuesPage FilteringStatusEntityStewardship(string StatusType)
        {
            driver.Navigate().Refresh();
            Thread.Sleep(6000);
            new HomePage(driver).SelectingWorkQueuesSubTab("Entity Stewardship");
            HelperActions.OnClick(entityStewardShipStatusFilterBtn, driver);
            for(int i=0; i<3;i++)
            {
                try
                {
                    var selectElemnt = driver.FindElements(statusDropDwnFilter);
                    foreach(IWebElement elemnt in selectElemnt)
                    {
                        if (elemnt.GetAttribute("innerText").Contains(StatusType)) {
                            if(!elemnt.Selected)
                                elemnt.Click();
                            i = 3;
                            break;
                            }
                    }
                }
                catch(NoSuchElementException) {
                        }Thread.Sleep(800);
            }
            return new WorkQueuesPage(driver);
        }
        public WorkQueuesPage Filtering2ndFilterEntityStewardship(string sourceType,String sourceValue)
        {
            HelperActions.OnClick(addFilterToEntityStewardShipBtn, driver);
            Thread.Sleep(500);
            HelperActions.selectOptionDropdownByText(entityStewardShipSourceFilterBtn, sourceType, driver);
            Thread.Sleep(1500);
            if (sourceType.Contains("Src Record"))
            {
                HelperActions.SendText(filteredValuetoSourceId, driver, sourceValue + "_1");
                new Actions(driver).KeyDown(Keys.Enter).Perform();
            }
            else if (sourceType.Contains("Import Process"))
            {
                HelperActions.selectRadioBtnInDropdown(filteredValuetoImportProcessDropDwn,sourceValue.Split("\\")[1],driver);
              
            }
            

            return new WorkQueuesPage(driver);
        }
        public void RemovingEntityStewardshipFilters()
        {
            var FilterElemnt = driver.FindElements(closeFiltersEntityStewardship);
            for (int i = FilterElemnt.Count; i > 2; i--)
            {
                var b = FilterElemnt.ElementAt(i-1).Enabled;
                FilterElemnt.ElementAt(i-1).Click();
            }
            Thread.Sleep(1000);
        }
        public bool ValidtingFilterdValueEntityStewardship(String filteredtxt,int count=1)
        {
            bool flag=false;
            for (int i = 0; i < 3; i++) {
                try
                {
                    var elm=driver.FindElements(By.XPath($"//*[@id='dgEntityStewList']//td[contains(text(),'{filteredtxt}')]"));
                    if (elm.Count == count)
                    {
                        flag = true;
                        break;
                    }
                    else
                    {
                        driver.Navigate().Refresh();
                        Thread.Sleep(1000);
                    }
                }
                catch (Exception) { Thread.Sleep(500);
                   
                }
                    }
            return flag;
        }


    }
}
