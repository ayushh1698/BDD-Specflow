﻿using DataHub.Helper;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Service_Portal.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataHub.Pages
{
    internal class IntegrationsPage
    {
        private IWebDriver driver;
        private HomePage homePage;
        public IntegrationsPage(IWebDriver driver) {
            this.driver = driver;
            homePage=new HomePage(driver);
        }
        protected By additionalActionDrpDwn = By.XPath("//button[@type='button'][contains(text(),'Additional Actions')]");
        protected By TemplateListBtn = By.Id("btnGetImportTemplatesList");
        protected By ImportDataDrpDwn = By.Id("btnImportFile");
        protected By ImportFileIndexNextBtn = By.Id("ImportFileIndexNext");
        protected By yesBtn = By.XPath("//*[@type='button'][contains(text(),'Yes')]");
        //##
        protected By importDataBrowserTxtBox = By.XPath("//*[@type='file']");
        protected By templateNameTxtBox = By.Id("templateName");
        protected By uploadFileNextBtn = By.Id("UploadFileNext");
        protected By sheetNameDrpDwn = By.Id("sheetName");
        protected By hasHeaderChkBox = By.Id("WithHeader");
        protected By finishImportDataUploadBtn = By.XPath("//*[@class='btn btn-primary TemplateButtons']");
        protected By errorMessageTemplateName = By.XPath("//*[@class='templateNameError error']");
        protected By deleteConfigName = By.XPath("//*[@class='deleteConfigureImports']");
        protected By searchConfigImportName = By.XPath("//input[@type='search']");
        protected By filteredConfigName = By.XPath("//*[@id='tbConfigureImport']//span[@class='WordBreak']");
        protected By importDataFinishBtn = By.Id("ComfirmDetailsFinish");

        public IntegrationsPage DeletingImportTemplate(string TemplateName,String? FileName=null)
        {
            driver.Navigate().Refresh();
            homePage.ClickingTab("Integration");
            homePage.SelectingIntegrationSubTab("Import Data");
            HelperActions.OnClick(additionalActionDrpDwn, driver);
            HelperActions.OnClick(TemplateListBtn, driver);
            WebDriverWait Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(45));
            By deleteBtn = By.XPath($"//span[@class='deleteTemplate cursor-pointer'][@data-templatename='{TemplateName}']");
            for (int i = 0; i <4; i++)
            {
                try
                {
                    IWebElement webElement = driver.FindElement(deleteBtn);
                    Wait.Until(d => webElement.Displayed || webElement.Enabled);
                    IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                    executor.ExecuteScript("arguments[0].click();", webElement);
                    break;
                }
                catch (Exception)
                {
                    Thread.Sleep(1000);
                }
            }
            //
            HelperActions.OnClick(yesBtn, driver);
            Thread.Sleep(500);
            Assert.True(HelperActions.GetNotificationMessage(driver).Contains("Data deleted successfully"));
            driver.Navigate().Refresh();
            return new IntegrationsPage(this.driver);
        }
        public IntegrationsPage ImportingData(string filePath,String sheetName)
        {
            By[] tm = { ImportDataDrpDwn, ImportFileIndexNextBtn, sheetNameDrpDwn };
            HelperActions.SendText(tm);
            HelperActions.SendText(ImportDataDrpDwn, ImportFileIndexNextBtn, sheetNameDrpDwn);
            HelperActions.OnClick(ImportFileIndexNextBtn, driver);          
            HelperActions.fileUpload(importDataBrowserTxtBox, filePath, driver);
            HelperActions.OnClick(hasHeaderChkBox, driver);
            HelperActions.selectOptionDropdownByText(sheetNameDrpDwn, sheetName, driver);
            HelperActions.OnClick(uploadFileNextBtn, driver);
            return new IntegrationsPage(this.driver);
        }
        public IntegrationsPage VerfyingImportedNotifications(string filePath, String sheetName)
        {
            HelperActions.OnClick(importDataFinishBtn, driver);
            //Assert.True(HelperActions.GetNotificationMessage(driver).Contains("File imported successfully"));
            return new IntegrationsPage(this.driver);
        }

    }
}
