﻿using NUnit.Framework;
using OpenQA.Selenium;
using Service_Portal.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataHub.Pages
{
    internal class DataHubPage
    {
        private IWebDriver driver;
        public DataHubPage(IWebDriver driver) => this.driver = driver;
        protected By dataHubHeader = By.XPath("//header//*[contains(text(), 'Data Hub')]");
        public DataHubPage VerifyDataHubPage()
        {
            Assert.IsTrue(HelperActions.ElementExists(dataHubHeader, driver),"Failed in Validting Data Hub Header");
            return new DataHubPage(driver);
        }
    }
}
