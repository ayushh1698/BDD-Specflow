﻿using OpenQA.Selenium;
using Service_Portal.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataHub.Pages
{
    internal class SearchPage
    {
        private IWebDriver driver;
        public SearchPage(IWebDriver driver) => this.driver = driver;

    }
}
