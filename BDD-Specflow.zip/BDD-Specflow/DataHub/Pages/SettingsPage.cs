using AventStack.ExtentReports.Utils;
using DataHub.Helper;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using Service_Portal.Helper;
using Service_Portal.Utility;
using System;
using System.Collections;
using System.Formats.Tar;
using System.Linq;
using System.Linq.Expressions;
using System.Xml.Linq;
namespace DataHub.Pages
{
    internal class SettingsPage
    {
        private IWebDriver driver;
        static String? emailId = null;
        public SettingsPage(IWebDriver driver) => this.driver = driver;
        //Portal
        protected By generalTab = By.Id("IdFeatureTab");
        protected By securityTab = By.Id("IdSecurityTab");
        protected By commonTab = By.Id("IdCommonTab");
        protected By dataHubTab = By.Id("IdDataHubTab");
        protected By dataIntegrationTab = By.Id("IdDataIntegration");
        protected By companyKnowledgeTab = By.Id("IdCompanyNameTab");
        protected By aboutUsTab = By.Id("IdAboutUsTab");

        protected By generalSettingsHeader = By.XPath("//header//*[contains(text(),'General Settings')]");
        protected By userHeader = By.XPath("//header//*[contains(text(),'User')]");
        protected By countryGroupHeader = By.XPath("//header//*[contains(text(),'Country Group')]");
        protected By hubGroupsHeader = By.XPath("//header//*[contains(text(),'Hub Groups')]");

        protected By configureImportListHeader = By.XPath("//header//*[contains(text(),'Configure Import List')]");

        protected By companyKnowledgebaseListHeader = By.XPath("//header//*[contains(text(),'Company Knowledgebase List')]");
        protected By companyCleaningListtHeader = By.XPath("//header//*[contains(text(),'Company Cleaning List')]");

        protected By aboutUsHeader = By.Id("divPartialAboutuUs");
        //Security
        //User
        protected By addUserBtn = By.Id("AddUser");
        protected By editUserBtn = By.Id("editUser");
        protected By userNameTxtBox = By.Id("UserName");
        protected By emailTxtBox = By.Id("EmailAddress");
        protected By userStatusCodeDropDwn = By.Id("UserStatusCode");
        protected By userTypeDropDwn = By.Id("UserTypeCode");
        protected By externalProviderDropDwn = By.Id("divIsTrustDeviceEnabled");
        protected By lobTagDropdwn = By.Id("LOBTag");
        protected By permissionDropdwn = By.CssSelector("[class='multiselect dropdown-toggle btn btn-default']");
        protected By userTab = By.Id("IdRTabUsers");
        protected By userSubmitBtn = By.Id("btnConfigDataUser");
        protected By enable30VerChckBox = By.CssSelector("[name='IsTrustDeviceEnabled']");
        protected By tagsInclusiveChckBox = By.CssSelector("[name='TagsInclusive']");
        //Domain Config
        protected By domainConfigTab = By.Id("IdRTabDomainConfiguration");
        protected By addDomainBtn = By.Id("AddDomainConfiguration");
        protected By editDomainBtn = By.Id("EditDomainConfiguration");
        protected By domainTxtB = By.Id("Domain");
        protected By submitBtn = By.Id("btnConfigurationId");
        protected By searchTxtBtn = By.XPath("//*[@class='dataTables_filter']/*[contains(text(),'Search')]");
        protected By deletUserDomain = By.XPath("//*[@class='deleteDomainConfiguration'][text()='Delete']");
        protected String filterDomainXPath = "//table[contains(@id,'DataTables_Table')]";
        //User List
        protected By confirmYes = By.XPath("//*[@class='btn btn-primary'][text()='Yes']");
        protected By firstUser = By.XPath("//*[@id='DataTables_Table_9']//*[contains(text(),'" + emailId + "')]");
        protected By deleteFirstUser = By.CssSelector("[class='deleteuser']");
        protected By NotificationMsg = By.XPath("//span[@data-notify='message']");
        protected By assignUserDropdwn = By.Id("ReassignToUserId");
        protected By deletUserBtn = By.Id("btnDeleteUser");
        protected By activationUserBtn = By.Id("ActivateUser");

        //DataHub Tab---
        //HubGroup
        protected By hubGroupTab = By.Id("IdRTabDataHubGroup");
        //protected By hubGroupTabSearch = By.Id("//*[@type='search']");
        protected By addDataHubGroupBtn = By.Id("AddDataHubGroup");
        protected By groupNameTxtBox = By.Id("GroupName");
        protected By groupNameSaveBtn = By.Id("btnConfigDataHubGroup");
        public static By HubGroupsearchTxtBtn = By.XPath("(//*[@class='dataTables_filter']/*[contains(text(),'Search')])[1]");
        string existVerify = "*//table[@class[contains(.,'table table-bordered')]]//tbody//td[1][contains(.,'";
        string editBtn = "*//table[@class[contains(.,'table table-bordered')]]//tbody//td[1][contains(.,'";
        string deleteBtn = "*//table[@class[contains(.,'table table-bordered')]]//tbody//td[1][contains(.,'";
        protected By deleteYesBtn = By.XPath(".//div[@class='modal-footer']//button[contains(.,'Yes')]");
        public static By logoutBtn = By.Id("logout");
        protected By logoutYesBtn = By.XPath(".//div[@class='MessageBoxButtonSection']//button[contains(.,'Yes')]");

        //HubSources
        protected By hubSourcesTab = By.Id("IdRTabDataHubSource");
        protected By addDataHubSourcesBtn = By.Id("AddSourceTag");
        protected By hubSourcesTabSearch = By.Id("//*[@type='search']");
        public static By hubSourcesSearchTxtBtn = By.XPath("(//*[@class='dataTables_filter']/*[contains(text(),'Search')])[2]");
        //settings
        protected By sourcepNameTxtBox = By.Id("hubSource_SourceName");
        protected By LOBTagDrpDwn = By.Id("hubSource_LobTag");
        protected By HubGroupDrpDwn = By.Id("hubSource_HubGroupId");
        protected By DuplicateImportDrpDwn = By.Id("hubSource_DuplicateImportOptionCode");
        protected By HubAutoAcceptanceDrpDwn = By.Id("hubSource_HubAutoAcceptanceCode");
        protected By ThirdPartySourcesDrpDwn = By.XPath(".//button[@title[contains(.,'Select Third Party Sources')]]");
        string ThirdPartySourcesMultiSelectDrpDwn = "//span[@class='multiselect-selected-text']";
        protected By sourceSaveBtn1 = By.Id("btnSourceSettingFinalSave");
        //Match Rules
        protected By MatchingThirdPartySourcesDrpDwn = By.Id("matchingThirdPartySources");
        protected By credentialsDrpDwn = By.Id("Credentials");
        protected By addThirdPartyCredBtn = By.Id("AddTPMatchRules");
        protected By adddescriptionTxtBox = By.Id("MatchPassDescription");
        protected By parameterDrpDwn = By.XPath("(.//button[@class[contains(.,'multiselect dropdown-toggle btn btn-default')]])[2]");
        string parameterMultiSelectDrpDwn = "(//span[@class='multiselect-selected-text'])[2]";
        protected By MatchrulesAddBtn = By.Id("btnMatchPassAdd");

        //CompanyKnowledgeBase
        protected By companyKnowledgeBaseTab = By.Id("IdRTabCompanyKnowledgeBase");
        protected By companyKnowledgeBaseFilter = By.XPath("//*[@id='filterValTag0'][@class='filterValue']");
        protected By companyCleaningTab = By.Id("IdRTabCompanyCleaning");
        protected By addCompanyKnowledgeBaseBtn = By.XPath("//div[@title='Add Company KnowledgeBase']");
        protected By copyKnowledgeBaseBtn = By.Id("btnCopyKnowledgebase");
        protected By tagFilterBtn = By.Id("ValueDetail0");
        protected By txtToSearchTxtB = By.Id("TextToSearch");
        protected By wordIndicator = By.Id("HubWordIndicatorListId");
        protected By txtToReplace = By.Id("TextToReplace");
        protected By wordPosition = By.Id("HubWordPositionListId");
        protected By tag = By.Id("Tag");
        protected By submitKnwledgeBase = By.Id("submitfrmAddUpdateKnowledgeBase");
        protected By filterTagSearch = By.XPath("//input[@class='form-control multiselect-search']");


        //Common Tab----
        protected By countryGroupsBaseTab = By.Id("IdRTabCountryGroup");
        protected By tagsTab = By.Id("IdRTabTags");
        protected By userCommentsTab = By.Id("IdRTabUserComment");
        protected By exportPageSettingsTab = By.Id("IdRTabExportPageSettings");
        protected By exportDestinationTab = By.Id("IdRTabConfigurationSettings");
        protected By encryptionKeyTab = By.Id("IdRTabEncryptionKey");
        protected By thirdPartyCredentialsTab = By.Id("IdRTabThirdPartyCredentials");
        //Country Groups
        protected By addCountryGroupsBtn = By.Id("AddCountryGroup");
        protected By editCountryGroupsBtn = By.Id("editCountryGroup");
        protected By groupNameTxtB = By.Id("objCountryGroup_GroupName");
        protected By allCountryDropBxBtn = By.Id("btnConfigCountryAllRight");
        protected By submitCountryGroupBtn = By.Id("btnConfigCountryGroup");
        //protected By searcTxtBtn = By.XPath("//*[@class='dataTables_filter']/*[contains(text(),'Search')]");
        protected By deleteCountryGroup = By.XPath("//*[@class='deleteCountryGroup'][text()='Delete']");
        //Tags
        protected By addTagsBtn = By.Id("AddTag");
        protected By editTagBtn = By.Id("editTag");
        protected By selectTagTypeDrpdwn = By.Id("TagTypeCode");
        protected By selectLOBTagDrpdwn = By.Id("LOBTag");
        protected By tagValueTxtB = By.Id("txtTags");
        protected By submitTagBtn = By.Id("btnSubmitTag");
        protected By duplicateTagNotification = By.XPath("//*[contains(text(),'This tag already exists')]");
        
        protected By confirmOK = By.XPath("//*[@class='btn btn-primary'][text()='OK']");
        protected By deleteTag = By.XPath("//*[@class='deleteTag'][text()='Delete']");
        protected By searchTagTxtBtn = By.XPath("//*[@class='dataTables_filter']/*[contains(text(),'Search')]");
        //User Comments
        protected By addUserCommentsBtn = By.Id("AddUserComment");
        protected By editUserCommentsBtn = By.Id("editUserComment");
        protected By selectCommentTypeDrpdwn = By.Id("CommentType");
        protected By UserCommentTxtB = By.Id("Comment");
        protected By submitUserCommentsBtn = By.Id("btnUsersComments");
        protected By deleteUserComments = By.XPath("//*[@class='DeleteUserComment'][text()=' Delete']");
        //Export Page Settings
        protected By MatchOutputTxtB = By.XPath("//input[@id='PAGE_SIZE_MATCH_OUTPUT']//..//input[2]");
        protected By EnrichmentOutputTxtB = By.XPath("//input[@id='PAGE_SIZE_ENRICHMENT_OUTPUT']//..//input[2]");
        protected By MonitoringOutputTxtB = By.XPath("//input[@id='PAGE_SIZE_MONITORING_OUTPUT']//..//input[2]");
        protected By QueueOutputTxtB = By.XPath("//input[@id='PAGE_SIZE_ACTIVE_DATA_QUEUE_OUTPUT']//..//input[2]");
        protected By ComplienceOutputTxtB = By.XPath("//input[@id='PAGE_SIZE_COMPLIANCE_OUTPUT']//..//input[2]");
        protected By ExportPageUpdateBtn = By.Id("btnSubmitExportPageSettings");
        //Export Destination
        protected By addExportDestBtn = By.Id("AddDataSource");
        protected By editExportDestBtn = By.XPath("//*[@class='editExternalDataSourceConfiguration'][text()='Edit']");
        protected By selectSFTPBtn = By.XPath("//input[@value='SFTP']");
        protected By SFTPDestNameTxtB = By.Id("sftp_SFTPExternalDataStoreName");
        protected By SFTPHostTxtB = By.Id("sftp_SFTPHost");
        protected By SFTPUserNameTxtB = By.Id("sftp_SFTPUserName");
        protected By SFTPPasswordTxtB = By.Id("sftp_SFTPPassword");
        protected By SFTPPortTxtB = By.Id("sftp_SFTPPort"); 
        protected By submitExportDestBtn = By.Id("btnSaveConfigurationSettings");
        protected By deleteExportDest = By.XPath("//*[@class='deleteExternalDataSourceConfiguration'][text()='Delete']");
        protected By searchExportDestTxtBtn = By.XPath("(//*[@class='dataTables_filter']/*[contains(text(),'Search')])[2]");
        
        //Company Cleaning
        protected By addCompanyCleaningBtn = By.XPath("//*[@title='Add Company Cleaning']");
        protected By hubTagDrpDwn = By.Id("HubWordTagBehaviourId");
        protected By submitCompanyCleaningBtn = By.Id("submitfrmAddUpdateCompanyCleaning");
        protected By editCompanyCleaningBtn = By.XPath("//*[@class='editCompanyCleaning']");
        protected By deleteCompanyCleaningBtn = By.XPath("//*[@class='deleteCompanyCleaning']");
        protected By closeBtn = By.XPath("//*[@type='button'][@class='close']");
        //EncryptionKey
        protected By addExportEncrpBtn = By.Id("btnAddKeyEncryptionKeySettings");
        protected By updateImportEncrpBtn = By.Id("UpdateEnableImportSettings");
        protected By enableImportEncrpToggleBtn = By.XPath("//*[@name='EnableImportSettings']/following-sibling::*[@class='Toggleslider round ']");
        protected By keyNameTxtBox = By.Id("KeyName");
        protected By encryptionFilePath = By.XPath("//*[@id='EncryptionFile']//*[contains(text(),'Browser')]");
        protected By browseBtn = By.Id("EncryptionFile");
        protected By searchEncryptionTxtBox = By.XPath("//*[@class='dataTables_filter']/*[contains(text(),'Search')]");
        protected By addExportFileBtn = By.Id("btnAddUpdateEncryptionKey");
        protected By filteredExportEncyptionData = By.XPath("//*[contains(@id,'DataTables_Table')]//*[@class='WordBreak']");
        protected By editExportEncyptionDataBtn = By.XPath("//*[contains(@id,'DataTables_Table')]//*[@class='editEncryptionKeySettings']");
        protected By deleteExportEncyptionDataBtn = By.XPath("//*[contains(@id,'DataTables_Table')]//*[@class='deleteEncryptionKeySettings']");
        protected By MBSEncyptionKey = By.XPath("//a[contains(@href,'Portal/DownloadEncryptionKey')]");

        //Data Integration
        protected By addConfigImportProcess = By.XPath("//*[@title='Add Configure Imports']");
        protected By addNewTemplateBtn = By.Id("addTransferDunsTag");
        protected By configurationNameTxtBox = By.Id("ConfigurationName");
        protected By fileTemplateDrpdwn = By.Id("TemplateIdEncrypted");
        protected By externalDataStoreDrpdwn = By.Id("ExternalDataStoreId");
        protected By folderPathTxtBox = By.Id("SourceFolderPath");
        protected By fileNamePatternTxtBox = By.Id("FileNamePattern");
        protected By saveBtn = By.XPath("//button[@type='submit']");
        protected By nextFileImportBtn = By.Id("ImportFileIndexNext");
        //protected By importDataBrowserTxtBox = By.XPath("//*[@type='file']//following-sibling::*");
        protected By importDataBrowserTxtBox = By.XPath("//*[@type='file']");
        protected By validateBtn = By.Id("btnValidSourcePath");
        protected By templateNameTxtBox = By.Id("templateName");
        protected By uploadFileNextBtn = By.Id("UploadFileNext");
        protected By hasHeaderChkBox = By.Id("WithHeader");
        protected By finishImportDataUploadBtn = By.XPath("//*[@class='btn btn-primary TemplateButtons']");
        protected By finishImportDataUploadBtn2 = By.Id("ColumnMappingFinish");
        protected By errorMessageTemplateName = By.XPath("//*[@class='templateNameError error']");
        protected By deleteConfigName = By.XPath("//*[@class='deleteConfigureImports']");
        protected By searchConfigImportName = By.XPath("//input[@type='search']");
        protected By filteredConfigName = By.XPath("//*[@id='tbConfigureImport']//span[@class='WordBreak']");


        public SettingsPage SelectingSettingsSubSubTabs(string SubTabName)
        {
            By subtabname = By.XPath("//a");
            By tabVerification = By.XPath("//*");
            switch (SubTabName.Trim().ToUpper().ToString())
            {
                case "GENERAL":
                    subtabname = generalTab;
                    tabVerification = generalSettingsHeader;
                    break;
                case "SECURITY":
                    subtabname = securityTab;
                    tabVerification = userHeader;
                    break;
                case "COMMON":
                    subtabname = commonTab;
                    tabVerification = countryGroupHeader;
                    break;
                case "DATA INTEGRATION":
                    subtabname = dataIntegrationTab;
                    tabVerification = configureImportListHeader;
                    break;
                case "COMPANY KNOWLEDGE BASE":
                    subtabname = companyKnowledgeTab;
                    tabVerification = companyKnowledgebaseListHeader;
                    break;
                case "ABOUT US":
                    subtabname = aboutUsTab;
                    tabVerification = aboutUsHeader;
                    break;
                case "DATA HUB":
                    subtabname = dataHubTab;
                    tabVerification = hubGroupsHeader;
                    break;

                default:
                    Console.WriteLine("Wrong Input");
                    break;
            }
            HelperActions.OnClick(subtabname, driver);
            Assert.IsTrue(HelperActions.ElementExists(tabVerification, driver), "failed in validating Settings tab within Subtab landing page");
            return new SettingsPage(driver);
        }
        public SettingsPage SelectingSecuritySubtab(string SubTabName)
        {
            By subtab = By.XPath("//a");
            SubTabName = SubTabName.Trim().ToUpper();
            if (SubTabName.Contains("USERS"))
            {
                subtab = userTab;
            }
            else if (SubTabName.Contains("DOMAIN CONFIG"))
            {
                subtab = domainConfigTab;
            }
            HelperActions.OnClick(subtab, driver);
            return new SettingsPage(driver);
        }
        public SettingsPage AddingUser(string userFields)
        {
            HelperActions.OnClick(addUserBtn, driver);
            int num = new Random().Next();
            emailId = userFields + DateTime.Today.DayOfYear + "" + num + "" + "@gmail.com";
            HelperActions.SendText(emailTxtBox, driver, emailId);
            FillingUserFields(userFields);
            Assert.True(HelperActions.GetNotificationMessage(driver).Contains("User created"), "Failed in Validating Created Notification Message getting " + HelperActions.GetNotificationMessage(driver));
            Thread.Sleep(1000);
            return new SettingsPage(driver);
        }
        public SettingsPage EditingUser(string modifiedFields)
        {
            HelperActions.OnClick(editUserBtn, driver);
            FillingUserFields(modifiedFields);
            Thread.Sleep(500);
            Assert.True(HelperActions.GetNotificationMessage(driver).Contains("User profile updated"), "Failed in Validating Update Notification Message");
            return new SettingsPage(driver);
        }
        public SettingsPage CRUDDomainConfiguration(String fieldvalue, String action = "ADD", String? updated = null)
        {
            action = action.ToUpper().Trim();
            if (action.Contains("ADD") || action.Contains("CREATE"))
            {
                HelperActions.OnClick(addDomainBtn, driver);
                HelperActions.SendText(domainTxtB, driver, fieldvalue);
                HelperActions.OnClick(submitBtn, driver);
                Assert.True(HelperActions.GetNotificationMessage(driver).Contains("already exists") || HelperActions.GetNotificationMessage(driver).Contains("Created successfully"));
            }
            else if (action.Contains("UPDATE") || action.Contains("EDIT"))
            {
                HelperActions.SendText(searchTxtBtn, driver, fieldvalue);
                HelperActions.OnClick(By.XPath(filterDomainXPath + $"//*[contains(text(),'{fieldvalue}')]"), driver);
                HelperActions.OnClick(editDomainBtn, driver);
                HelperActions.SendText(domainTxtB, driver, updated);
                HelperActions.OnClick(submitBtn, driver);
                HelperActions.GetNotificationMessage(driver).Contains("Updated successfully");
            }
            else if (action.Contains("DELETE"))
            {
                HelperActions.SendText(searchTxtBtn, driver, fieldvalue);
                HelperActions.OnClick(By.XPath(filterDomainXPath + $"//*[contains(text(),'{fieldvalue}')]"), driver);
                HelperActions.OnClick(deletUserDomain, driver);
                HelperActions.OnClick(confirmYes, driver);
                HelperActions.GetNotificationMessage(driver).Contains("Deleted successfully");
            }
            return new SettingsPage(driver);
        }
        public SettingsPage ValidatingDomain(string DomainName, Boolean Flag = true)
        {

            Thread.Sleep(1200);
            if (Flag)
            {
                HelperActions.SendText(searchTxtBtn, driver, DomainName);
                Thread.Sleep(800);
                Assert.True(HelperActions.ElementExists(By.XPath(filterDomainXPath + $"//*[contains(text(),'{DomainName}')]"), driver));
            }
            else
            {
                HelperActions.SendText(searchTxtBtn, driver, DomainName);
                Thread.Sleep(800);
                Assert.True(HelperActions.ElementExists(By.XPath(filterDomainXPath + $"//*[contains(text(),'No records found')]"), driver));
            }
            return new SettingsPage(driver);
        }
        public SettingsPage DeletingUser(string username)
        {
            HelperActions.OnClick(deleteFirstUser, driver);
            new Actions(driver).SendKeys(Keys.Enter).Perform();
            Assert.IsTrue(HelperActions.ElementExists(assignUserDropdwn, driver), "failed in validating filtered user in the list");
            HelperActions.SelectDropDownFirstOption(assignUserDropdwn, driver);
            HelperActions.OnClick(deletUserBtn, driver);
            Assert.True(HelperActions.GetNotificationMessage(driver).Contains("User deleted successfully"), "Failed in Validating Update Notification Message");
            return new SettingsPage(driver);
        }
        public SettingsPage SearchingUser(string userFields)
        {
            var username = userFields + DateTime.Today.DayOfYear + DateTime.Today.DayOfWeek;
            HelperActions.OnClick(searchTxtBtn, driver);
            HelperActions.SendText(searchTxtBtn, driver, username);
            new Actions(driver).KeyDown(Keys.Enter).Perform();
            Thread.Sleep(1500);
            var firstUser = "//*[starts-with(@id,'DataTables_Table_')]//*[contains(text(),'" + username + "')]";
            HelperActions.OnClick(By.XPath(firstUser), driver);
            Thread.Sleep(1400);

            return new SettingsPage(driver);
        }
        public SettingsPage ValidatingUserIsDeleted()
        {
            if (HelperActions.ElementExists(activationUserBtn, driver))
                Assert.Pass("Sucessfully validated the delete icon for deleted entry");
            else
                Assert.Fail("Failed in Validating the delete icon for deleted entry");
            return new SettingsPage(driver);
        }
        protected SettingsPage FillingUserFields(string userName)
        {
            var username = userName + DateTime.Today.DayOfYear + DateTime.Today.DayOfWeek;
            emailId = userName + DateTime.Today.DayOfYear + "@gmail.com";
            username = username.Replace(" ", "");
            HelperActions.SendText(userNameTxtBox, driver, username);
            By[] userColumn = { userStatusCodeDropDwn, lobTagDropdwn };
            //HelperActions.SelectDropDownText(userTypeDropDwn, "Data Steward", driver);
            HelperActions.selectOptionDropdownByText(userTypeDropDwn, "Data Steward", driver);
            HelperActions.SelectDropDownCheckbx(permissionDropdwn, "Export data", driver);
            //Testing Phase
            foreach (var UserField in userColumn)
            {
                HelperActions.SelectDropDownFirstOption(UserField, driver);
            }
            HelperActions.OnClick(userSubmitBtn, driver);
            return new SettingsPage(driver);
        }


        //Datahub -- section

        //Hub Groups section

        public SettingsPage SelectingDataHubSubtab(string SubTabName)
        {
            By subtab = By.XPath("//a");
            SubTabName = SubTabName.Trim().ToUpper();
            if (SubTabName.Contains("HUB GROUP"))
            {
                subtab = hubGroupTab;
                Thread.Sleep(2000);
            }
            else if (SubTabName.Contains("HUB SOURCES"))
            {
                subtab = hubSourcesTab;
                Thread.Sleep(2000);
            }
            HelperActions.OnClick(subtab, driver);
            return new SettingsPage(driver);
        }

        public SettingsPage ClickAddHubGroup()
        {
            try
            {
                Thread.Sleep(2000);
                if (driver.FindElement(addDataHubGroupBtn).Displayed)
                {
                    Console.WriteLine("clicking add button");
                    HelperActions.OnClick(addDataHubGroupBtn, driver);
                }
                else
                    Console.WriteLine("Add button is not dispayed");
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage ClickEditHubGroup(string value)
        {
            string xpath = editBtn + value + "')]//..//a[contains(@title,'Edit')]";
            try
            {
                //Thread.Sleep(2000);
                if (driver.FindElement(By.XPath(existVerify + value + "')]")).Displayed)
                {
                    Console.WriteLine("clicking Edit button");
                    HelperActions.OnClick((By.XPath(xpath)), driver);
                    ExtendReport.Pass("Edit button is visible and clicked");
                }
                else
                    Console.WriteLine("Edit button is not dispayed");
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage ClickOnDeleteAndConfirm(string value)
        {
            string xpath = deleteBtn + value + "')]//..//a[contains(@title,'Delete')]";
            //IWebElement delete = driver.FindElement(By.XPath(xpath));
            try
            {
                Thread.Sleep(2000);
                if (driver.FindElement(By.XPath(existVerify + value + "')]")).Displayed)
                {
                    HelperActions.OnClick(By.XPath(xpath), driver);
                    Thread.Sleep(2000);
                    HelperActions.OnClick(deleteYesBtn, driver);
                }
                else
                    Console.WriteLine("Delete button is not dispayed");
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage AddingGroupName(string groupName)
        {
            //var username = userFields + DateTime.Today;
            //emailId = userFields + "@gmail.com";
            for(int i=0;i<5;i++)
            try
            {
                if ((driver.FindElement(groupNameTxtBox).Displayed))
                {
                    Console.WriteLine("Group Name text box is displayed.");
                    driver.FindElement(groupNameTxtBox).Clear();
                    HelperActions.SendText(groupNameTxtBox, driver, groupName);
                    Thread.Sleep(2000);
                    break;
                }
                else
                    Console.WriteLine("Group Name text box is not displayed.");
            }
            catch (Exception)
            {
                Thread.Sleep(800);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage ClickOnSave()
        {
            //var username = userFields + DateTime.Today;
            //emailId = userFields + "@gmail.com";
            try
            {
                HelperActions.OnClick(groupNameSaveBtn, driver);
                Thread.Sleep(2000);
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage VerifyExisting(string value)
        {
            string xpath = existVerify + value + "')]";
            Console.WriteLine(xpath);
            //Thread.Sleep(3000);
            try
            {
                HelperActions.WebElementWait(searchTxtBtn, driver);
                driver.FindElement(searchTxtBtn).SendKeys(value);
                //Thread.Sleep(1000);
                //var size1 = driver.FindElements(By.XPath(existVerify + value + "')]")).Count;

                if (driver.FindElement(By.XPath(xpath)).Displayed)
                {
                    ExtendReport.Pass("Required data is present in the table");
                }
                else
                {
                    Console.WriteLine("Required data is not present in the table");
                    Assert.Fail();
                }

            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage VerifyDeletedExisting(string value)
        {
            string xpath = existVerify + value + "')]";
            HelperActions.WebElementWait(searchTxtBtn, driver);
            try
            {
                HelperActions.SendText(searchTxtBtn, driver, value);

                //var size1 = driver.FindElements(By.XPath(existVerify + value + "')]")).Count;

                if ((driver.FindElements(By.XPath(xpath)).Count) == 0)
                {
                    ExtendReport.Pass("data is deleted successfully");
                    //Assert.Pass();
                }
                else
                {
                    ExtendReport.Fail("Group Name is in table.");
                    //Assert.Fail();
                }

            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }
            Thread.Sleep(2000);
            return new SettingsPage(driver);
        }


        public SettingsPage ClickOnLogout()
        {
            //var username = userFields + DateTime.Today;
            //emailId = userFields + "@gmail.com";
            try
            {
                if (driver.FindElement(By.XPath("//*[@class='close']")).Displayed)
                {
                    Thread.Sleep(1000);
                    driver.FindElement(By.XPath("//*[@class='close']")).Click();
                }
                //HelperActions.OnClick(logoutBtn, driver);
                HelperActions.WebElementWait(logoutBtn, driver);
                driver.FindElement(logoutBtn).Click();
                Thread.Sleep(1000);
                // ExtendReport.Pass("clicked on Logout button");
                ExtendReport.Pass("clicked on Logout button");
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage ClickOnYesLogout()
        {
            //var username = userFields + DateTime.Today;
            //emailId = userFields + "@gmail.com";
            try
            {
                HelperActions.WebElementWait(logoutYesBtn, driver);
                driver.FindElement(logoutYesBtn).Click();
                ExtendReport.Pass("Confirmed Yes in Logout");
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }


        //Hub Sources Section

        public SettingsPage ClickOnAddHubSources()
        {
            HelperActions.WebElementWait(addDataHubSourcesBtn, driver);
            try
            {
                if (driver.FindElement(addDataHubSourcesBtn).Displayed)
                {
                    driver.FindElement(addDataHubSourcesBtn).Click();
                    ExtendReport.Pass("Clicked on Add button for Hub Sources");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage EnterSourceName(string SourceName)
        {
            HelperActions.WebElementWait(sourcepNameTxtBox, driver);
            try
            {
                if (driver.FindElement(sourcepNameTxtBox).Enabled)
                {
                    driver.FindElement(sourcepNameTxtBox).SendKeys(SourceName);
                    ExtendReport.Pass("Entered Source Name successfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }


        public SettingsPage SelectSourcesLOBTag(string LOBTagValue)
        {
            HelperActions.WebElementWait(LOBTagDrpDwn, driver);
            try
            {
                if (driver.FindElement(LOBTagDrpDwn).Enabled)
                {
                    HelperActions.selectOptionDropdownByText(LOBTagDrpDwn, LOBTagValue, driver);
                    ExtendReport.Pass("Selected LOB Tag value successfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage SelectSourcesHubGroup(string HubGroupValue)
        {
            HelperActions.WebElementWait(HubGroupDrpDwn, driver);
            try
            {
                if (driver.FindElement(HubGroupDrpDwn).Enabled)
                {
                    HelperActions.selectOptionDropdownByText(HubGroupDrpDwn, HubGroupValue, driver);
                    ExtendReport.Pass("Selected Hub Group value successfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage SelectSourcesDuplicate(string DuplicateValue)
        {
            HelperActions.WebElementWait(DuplicateImportDrpDwn, driver);
            try
            {
                if (driver.FindElement(DuplicateImportDrpDwn).Enabled)
                {
                    HelperActions.selectOptionDropdownByText(DuplicateImportDrpDwn, DuplicateValue, driver);
                    ExtendReport.Pass("Selected Duplicate Import Option value successfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage SelectSourcesHubAutoAcceptance(string AutoAcceptanceValue)
        {
            HelperActions.WebElementWait(HubAutoAcceptanceDrpDwn, driver);
            try
            {
                if (driver.FindElement(HubAutoAcceptanceDrpDwn).Enabled)
                {
                    HelperActions.selectOptionDropdownByText(HubAutoAcceptanceDrpDwn, AutoAcceptanceValue, driver);
                    ExtendReport.Pass("Selected Hub Auto Acceptance Value successfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage SelectSourcesThirdPartyChkbx(string ThirdPartyChkbxValue)
        {
            HelperActions.WebElementWait(ThirdPartySourcesDrpDwn, driver);
            try
            {
                if (driver.FindElement(ThirdPartySourcesDrpDwn).Enabled)
                {
                    HelperActions.selectCheckboxInDropdown(ThirdPartySourcesMultiSelectDrpDwn, ThirdPartyChkbxValue, driver);
                    ExtendReport.Pass("Selected Third Party Sources Value successfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage ClickOnSaveNext()
        {
            HelperActions.WebElementWait(sourceSaveBtn1, driver);
            try
            {
                if (driver.FindElement(sourceSaveBtn1).Displayed && driver.FindElement(sourceSaveBtn1).Enabled)
                {
                    HelperActions.OnClick(sourceSaveBtn1, driver);
                    ExtendReport.Pass("Click Save is successfull");
                    Thread.Sleep(2000);
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage selectMatchRulesThirdPartySources(string MatchRulesThirdPartySourcesValue)
        {
            HelperActions.WebElementWait(MatchingThirdPartySourcesDrpDwn, driver);
            try
            {
                if (driver.FindElement(MatchingThirdPartySourcesDrpDwn).Displayed && driver.FindElement(MatchingThirdPartySourcesDrpDwn).Enabled)
                {
                    HelperActions.selectOptionDropdownByText(MatchingThirdPartySourcesDrpDwn, MatchRulesThirdPartySourcesValue, driver);
                    ExtendReport.Pass("Selected Match Rules Third Party Sources Value successfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage selectMatchRulesCredentials(string MatchRulesCredentialsValue)
        {
            HelperActions.WebElementWait(credentialsDrpDwn, driver);
            try
            {
                if (driver.FindElement(credentialsDrpDwn).Displayed && driver.FindElement(credentialsDrpDwn).Enabled)
                {
                    HelperActions.selectOptionDropdownByText(credentialsDrpDwn, MatchRulesCredentialsValue, driver);
                    ExtendReport.Pass("Selected Match Rules Credentials Value successfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage ClickonAddThirdPartyCredBtn()
        {
            HelperActions.WebElementWait(addThirdPartyCredBtn, driver);
            try
            {
                if (driver.FindElement(addThirdPartyCredBtn).Displayed && driver.FindElement(addThirdPartyCredBtn).Enabled)
                {
                    HelperActions.OnClick(addThirdPartyCredBtn, driver);
                    HelperActions.WebElementWait(adddescriptionTxtBox, driver);
                    ExtendReport.Pass("Clicked Add button in Credentials successfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage AddDescriptiontext(string DescriptionValue)
        {
            HelperActions.WebElementWait(adddescriptionTxtBox, driver);
            try
            {
                if (driver.FindElement(adddescriptionTxtBox).Displayed && driver.FindElement(adddescriptionTxtBox).Enabled)
                {
                    driver.FindElement(adddescriptionTxtBox).SendKeys(DescriptionValue);
                    ExtendReport.Pass("Added Description Value successfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage SelectParameter(string ParameterValue)
        {
            HelperActions.WebElementWait(parameterDrpDwn, driver);
            try
            {
                if (driver.FindElement(adddescriptionTxtBox).Displayed && driver.FindElement(adddescriptionTxtBox).Enabled)
                {
                    HelperActions.selectCheckboxInDropdown(parameterMultiSelectDrpDwn, ParameterValue, driver);
                    driver.FindElement(parameterDrpDwn).SendKeys(Keys.Tab);
                    ExtendReport.Pass("Selected Parameter Value successfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage ClickAddMatchRule()
        {
            HelperActions.WebElementWait(MatchrulesAddBtn, driver);
            try
            {
                if (driver.FindElement(MatchrulesAddBtn).Displayed && driver.FindElement(MatchrulesAddBtn).Enabled)
                {
                    HelperActions.OnClick(MatchrulesAddBtn, driver);
                    ExtendReport.Pass("Match Rule Add button clickedsuccessfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }


        public SettingsPage VerifyHubSourceExisting(string value)
        {
            string xpath = existVerify + value + "')]";
            Console.WriteLine(xpath);
            //Thread.Sleep(3000);
            try
            {
                HelperActions.WebElementWait(hubSourcesSearchTxtBtn, driver);
                driver.FindElement(hubSourcesSearchTxtBtn).SendKeys(value);
                //Thread.Sleep(1000);
                //var size1 = driver.FindElements(By.XPath(existVerify + value + "')]")).Count;

                if (driver.FindElement(By.XPath(xpath)).Displayed)
                {
                    ExtendReport.Pass("Required data is present in the table");
                }
                else
                {
                    Console.WriteLine("Required data is not present in the table");
                    Assert.Fail();
                }

            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }

        public SettingsPage VerifyHubSourceDeletedExisting(string value)
        {
            string xpath = existVerify + value + "')]";
            HelperActions.WebElementWait(hubSourcesSearchTxtBtn, driver);
            try
            {
                HelperActions.SendText(hubSourcesSearchTxtBtn, driver, value);

                //var size1 = driver.FindElements(By.XPath(existVerify + value + "')]")).Count;

                if ((driver.FindElements(By.XPath(xpath)).Count) == 0)
                {
                    ExtendReport.Pass("data is deleted successfully");
                    //Assert.Pass();
                }
                else
                {
                    ExtendReport.Fail("Group Name is in table.");
                    //Assert.Fail();
                }

            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }
            Thread.Sleep(2000);
            return new SettingsPage(driver);
        }


        //Common Tab section

        public SettingsPage SelectingCommonSubtab(string SubTabName)
        {
            By subtab = By.XPath("//a");
            SubTabName = SubTabName.Trim().ToUpper();
            if (SubTabName.Contains("COUNTRY GROUPS"))
            {
                subtab = countryGroupsBaseTab;
            }
            else if (SubTabName.Contains("TAGS"))
            {
                subtab = tagsTab;
            }
            else if (SubTabName.Contains("USER COMMENTS"))
            {
                subtab = userCommentsTab;
            }
            else if (SubTabName.Contains("EXPORT PAGE SETTINGS"))
            {
                subtab = exportPageSettingsTab;
            }
            else if (SubTabName.Contains("EXPORT DESTINATION"))
            {
                subtab = exportDestinationTab;
            }
            else if (SubTabName.Contains("ENCRYPTION KEY"))
            {
                subtab = encryptionKeyTab;
            }
            else if (SubTabName.Contains("THIRD PARTY CREDENTIALS"))
            {
                subtab = thirdPartyCredentialsTab;
            }
            HelperActions.OnClick(subtab, driver);
            return new SettingsPage(driver);
        }

        //Country Groups tab-----

        public SettingsPage CRUDCountryGroups(String fieldvalue, String action = "ADD", String? updated = null)
        {
            action = action.ToUpper().Trim();
            if (action.Contains("ADD") || action.Contains("CREATE"))
            {
                HelperActions.OnClick(addCountryGroupsBtn, driver);
                HelperActions.SendText(groupNameTxtB, driver, fieldvalue);
                HelperActions.OnClick(allCountryDropBxBtn, driver);
                HelperActions.OnClick(submitCountryGroupBtn, driver);
                Thread.Sleep(1000);
                Assert.True(HelperActions.GetNotificationMessage(driver).Contains("already exists") || HelperActions.GetNotificationMessage(driver).Contains("created successfully"));
            }
            else if (action.Contains("UPDATE") || action.Contains("EDIT"))
            {
                Thread.Sleep(3000);
                HelperActions.SendText(searchTxtBtn, driver, fieldvalue);
                HelperActions.OnClick(By.XPath(filterDomainXPath + $"//*[contains(text(),'{fieldvalue}')]"), driver);
                HelperActions.WebElementWait(editCountryGroupsBtn, driver);
                HelperActions.OnClick(editCountryGroupsBtn, driver);
                HelperActions.SendText(groupNameTxtB, driver, updated);
                HelperActions.OnClick(submitCountryGroupBtn, driver);
                Thread.Sleep(800);
                HelperActions.GetNotificationMessage(driver).Contains("updated successfully");
            }
            else if (action.Contains("DELETE"))
            {
                Thread.Sleep(3000);
                HelperActions.SendText(searchTxtBtn, driver, fieldvalue);
                HelperActions.OnClick(By.XPath(filterDomainXPath + $"//*[contains(text(),'{fieldvalue}')]"), driver);
                HelperActions.OnClick(deleteCountryGroup, driver);
                HelperActions.OnClick(confirmYes, driver);
                Thread.Sleep(800);
                HelperActions.GetNotificationMessage(driver).Contains("deleted successfully");
            }
            return new SettingsPage(driver);
        }

        public SettingsPage ValidatingCountryGroup(string countryGroupName, Boolean Flag = true)
        {

            Thread.Sleep(1200);
            if (Flag)
            {
                HelperActions.WebElementWait(searchTxtBtn, driver);
                HelperActions.SendText(searchTxtBtn, driver, countryGroupName);
                Thread.Sleep(800);
                Assert.True(HelperActions.ElementExists(By.XPath(filterDomainXPath + $"//*[contains(text(),'{countryGroupName}')]"), driver));
            }
            else
            {
                HelperActions.WebElementWait(searchTxtBtn, driver);
                HelperActions.SendText(searchTxtBtn, driver, countryGroupName);
                Thread.Sleep(800);
                Assert.True(HelperActions.ElementExists(By.XPath(filterDomainXPath + $"//*[contains(text(),'No records found')]"), driver));
            }
            return new SettingsPage(driver);
        }



        //Tags tab-----

        public SettingsPage CRUDTags(String fieldvalue, String action = "ADD")
        {
            action = action.ToUpper().Trim();
            if (action.Contains("ADD") || action.Contains("CREATE"))
            {
                HelperActions.OnClick(addTagsBtn, driver);
                HelperActions.SendText(tagValueTxtB, driver, fieldvalue);
                HelperActions.SelectDropDownFirstOption(selectTagTypeDrpdwn, driver);
                HelperActions.OnClick(submitTagBtn, driver);
               // if (!HelperActions.ElementExists(duplicateTagNotification, driver))
                    Assert.True(HelperActions.GetNotificationMessage(driver).Contains("already exists") || HelperActions.GetNotificationMessage(driver).Contains("created successfully"));
               // else
                   // HelperActions.OnClick(confirmOK, driver);
            }
            else if (action.Contains("UPDATE") || action.Contains("EDIT"))
            {
                Thread.Sleep(3000);
                HelperActions.SendText(searchTagTxtBtn, driver, fieldvalue);
                HelperActions.OnClick(By.XPath(filterDomainXPath + $"//*[contains(text(),'{fieldvalue}')]"), driver);
                HelperActions.WebElementWait(editTagBtn, driver);
                HelperActions.OnClick(editTagBtn, driver);
                HelperActions.selectOptionDropdownByText(selectLOBTagDrpdwn,"", driver,3);
                HelperActions.OnClick(submitTagBtn, driver);
                //if (!HelperActions.ElementExists(duplicateTagNotification, driver))
                    Assert.True(HelperActions.GetNotificationMessage(driver).Contains("updated successfully"));
                //else
                    //HelperActions.OnClick(confirmOK, driver);
            }
            else if (action.Contains("DELETE"))
            {
                Thread.Sleep(3000);
                HelperActions.SendText(searchTagTxtBtn, driver, fieldvalue);
                HelperActions.OnClick(By.XPath(filterDomainXPath + $"//*[contains(text(),'{fieldvalue}')]"), driver);
                HelperActions.OnClick(deleteTag, driver);
                HelperActions.OnClick(confirmYes, driver);
                HelperActions.GetNotificationMessage(driver).Contains("deleted successfully");
            }
            return new SettingsPage(driver);
        }

        public SettingsPage ValidatingTags(string tagName, Boolean Flag = true)
        {

            Thread.Sleep(1200);
            if (Flag)
            {
                HelperActions.WebElementWait(searchTagTxtBtn, driver);
                HelperActions.SendText(searchTagTxtBtn, driver, tagName);
                Thread.Sleep(1200);
                Assert.True(HelperActions.ElementExists(By.XPath(filterDomainXPath + $"//*[contains(text(),'{tagName}')]"), driver));
            }
            else
            {
                HelperActions.WebElementWait(searchTagTxtBtn, driver);
                HelperActions.SendText(searchTagTxtBtn, driver, tagName);
                Thread.Sleep(1200);
                Assert.True(HelperActions.ElementExists(By.XPath(filterDomainXPath + $"//*[contains(text(),'No records found')]"), driver));
            }
            return new SettingsPage(driver);
        }



        //User Comments tab-----

        public SettingsPage CRUDUserComments(String fieldvalue, String action = "ADD", String? updated = null)
        {
            action = action.ToUpper().Trim();
            if (action.Contains("ADD") || action.Contains("CREATE"))
            {
                HelperActions.OnClick(addUserCommentsBtn, driver);
                HelperActions.SelectDropDownFirstOption(selectCommentTypeDrpdwn, driver);
                HelperActions.SendText(UserCommentTxtB, driver, fieldvalue);
                HelperActions.OnClick(submitUserCommentsBtn, driver);
                Thread.Sleep(1000);
                Assert.True(HelperActions.GetNotificationMessage(driver).Contains("already exists") || HelperActions.GetNotificationMessage(driver).Contains("created successfully"));
            }
            else if (action.Contains("UPDATE") || action.Contains("EDIT"))
            {
                Thread.Sleep(3000);
                HelperActions.SendText(searchTagTxtBtn, driver, fieldvalue);
                HelperActions.OnClick(By.XPath(filterDomainXPath + $"//*[contains(text(),'{fieldvalue}')]"), driver);
                HelperActions.WebElementWait(editUserCommentsBtn, driver);
                HelperActions.OnClick(editUserCommentsBtn, driver);
                HelperActions.SendText(UserCommentTxtB, driver, updated);
                HelperActions.OnClick(submitUserCommentsBtn, driver);
                HelperActions.GetNotificationMessage(driver).Contains("updated successfully");
            }
            else if (action.Contains("DELETE"))
            {
                Thread.Sleep(3000);
                HelperActions.SendText(searchTagTxtBtn, driver, fieldvalue);
                HelperActions.OnClick(By.XPath(filterDomainXPath + $"//*[contains(text(),'{fieldvalue}')]"), driver);
                HelperActions.OnClick(deleteUserComments, driver);
                HelperActions.OnClick(confirmYes, driver);
                HelperActions.GetNotificationMessage(driver).Contains("deleted successfully");
            }
            return new SettingsPage(driver);
        }

        public SettingsPage ValidatingUserComments(string fieldvalue, Boolean Flag = true)
        {

            Thread.Sleep(1200);
            if (Flag)
            {
                HelperActions.WebElementWait(searchTagTxtBtn, driver);
                HelperActions.SendText(searchTagTxtBtn, driver, fieldvalue);
                Thread.Sleep(1200);
                Assert.True(HelperActions.ElementExists(By.XPath(filterDomainXPath + $"//*[contains(text(),'{fieldvalue}')]"), driver));
            }
            else
            {
                HelperActions.WebElementWait(searchTagTxtBtn, driver);
                HelperActions.SendText(searchTagTxtBtn, driver, fieldvalue);
                Thread.Sleep(1200);
                Assert.True(HelperActions.ElementExists(By.XPath(filterDomainXPath + $"//*[contains(text(),'No records found')]"), driver));
            }
            return new SettingsPage(driver);
        }

//Export Page Settings tab----

        public SettingsPage updateExportPageSettings()
        {
            HelperActions.WebElementWait(MatchOutputTxtB, driver);
            try
            {
                if (driver.FindElement(MatchOutputTxtB).Displayed && driver.FindElement(MatchOutputTxtB).Enabled)
                {
                    HelperActions.SendText(MatchOutputTxtB, driver, "50");
                    HelperActions.SendText(EnrichmentOutputTxtB, driver, "50");
                    HelperActions.SendText(MonitoringOutputTxtB, driver, "50");
                    HelperActions.SendText(QueueOutputTxtB, driver, "50");
                    HelperActions.SendText(ComplienceOutputTxtB, driver, "50");
                    HelperActions.OnClick(ExportPageUpdateBtn, driver);
                    ExtendReport.Pass("Match Rule Add button clickedsuccessfully");
                }
            }
            catch (Exception ex)
            {
                ExtendReport.Fail(ex.Message);
            }

            return new SettingsPage(driver);
        }




      //Export Destination tab------
        public SettingsPage CRUDExportDestination(String ExportDestName, String action = "ADD", String updated = null)
        {
            action = action.ToUpper().Trim();
            if (action.Contains("ADD") || action.Contains("CREATE"))
            {
                HelperActions.OnClick(addExportDestBtn, driver);
                HelperActions.WebElementWait(selectSFTPBtn, driver);
                HelperActions.OnClick(selectSFTPBtn, driver);
                HelperActions.WebElementWait(SFTPDestNameTxtB, driver);
                HelperActions.SendText(SFTPDestNameTxtB, driver, ExportDestName);
                HelperActions.SendText(SFTPHostTxtB, driver, EnvironmentDataHelper.GetData("Host", "DataHub"));
                HelperActions.SendText(SFTPUserNameTxtB, driver, EnvironmentDataHelper.GetData("UserName", "DataHub"));
                HelperActions.SendText(SFTPPasswordTxtB, driver, EnvironmentDataHelper.GetData("Password", "DataHub"));
                HelperActions.SendText(SFTPPortTxtB, driver, EnvironmentDataHelper.GetData("Port", "DataHub"));
                HelperActions.OnClick(submitExportDestBtn, driver);
                Thread.Sleep(1000);
               Assert.True(HelperActions.GetNotificationMessage(driver).Contains("already exists") || HelperActions.GetNotificationMessage(driver).Contains("created successfully"));
            }
            else if (action.Contains("UPDATE") || action.Contains("EDIT"))
            {
                Thread.Sleep(3000);
                HelperActions.SendText(searchTagTxtBtn, driver, ExportDestName);
                HelperActions.OnClick(By.XPath(filterDomainXPath + $"//*[contains(text(),'{ExportDestName}')]"), driver);
                HelperActions.OnClick(editExportDestBtn, driver);
                HelperActions.WebElementWait(SFTPDestNameTxtB, driver);
                HelperActions.SendText(SFTPDestNameTxtB, driver, updated);
                HelperActions.OnClick(submitExportDestBtn, driver);
                HelperActions.GetNotificationMessage(driver).Contains("updated successfully");
            }
            else if (action.Contains("DELETE"))
            {
                Thread.Sleep(3000);
                HelperActions.SendText(searchTagTxtBtn, driver, ExportDestName);
                HelperActions.OnClick(By.XPath(filterDomainXPath + $"//*[contains(text(),'{ExportDestName}')]"), driver);
                HelperActions.OnClick(deleteExportDest, driver);
                HelperActions.OnClick(confirmYes, driver);
                HelperActions.GetNotificationMessage(driver).Contains("deleted successfully");
            }
            return new SettingsPage(driver);
        }

        public SettingsPage ValidatingExportDestination(string fieldvalue, Boolean Flag = true)
        {

            Thread.Sleep(1200);
            if (Flag)
            {
                HelperActions.WebElementWait(searchTagTxtBtn, driver);
                HelperActions.SendText(searchTagTxtBtn, driver, fieldvalue);
                Thread.Sleep(800);
                Assert.True(HelperActions.ElementExists(By.XPath(filterDomainXPath + $"//*[contains(text(),'{fieldvalue}')]"), driver));
            }
            else
            {
                HelperActions.WebElementWait(searchTagTxtBtn, driver);
                HelperActions.SendText(searchTagTxtBtn, driver, fieldvalue);
                Thread.Sleep(800);
                Assert.True(HelperActions.ElementExists(By.XPath(filterDomainXPath + $"//*[contains(text(),'No records found')]"), driver));
            }
            return new SettingsPage(driver);
        }

        

        //Company Knowledge Base section
        public SettingsPage SelectingCompanyKnowledgeBaseSubtab(string SubTabName)
        {
            By subtab = By.XPath("//a");
            By headerVerification = By.XPath("//");
            SubTabName= SubTabName.Trim().ToUpper();
            if (SubTabName.Contains("COMPANY KNOWLEDGE"))
            {
                subtab = companyKnowledgeBaseTab;
                headerVerification = companyKnowledgebaseListHeader;
            }
            else if (SubTabName.Contains("COMPANY CLEANING"))
            {
                subtab = companyCleaningTab;
                headerVerification = companyCleaningListtHeader;
            }
            HelperActions.OnClick(subtab, driver);
            Assert.IsTrue(HelperActions.ElementExists(headerVerification, driver), "Failed in Validating teh landing page Header"); ;
            return new SettingsPage(driver);
        }
        public SettingsPage CRUDCompanyKnowledgeBase(string fieldvalue, string action, string updatedvalue)
        {
            int i; SelectElement select; var jsDriver = (IJavaScriptExecutor)driver;
            string highlightJavascript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color: red"";";
            string tagName = EnvironmentDataHelper.GetData("Tag","CompanyKnowledgeBase");
            ((IJavaScriptExecutor)driver).ExecuteScript("window.scrollTo(document.body.scrollHeight, 0)");
            action = action.ToUpper().Trim();
            if (action.Contains("ADD") || action.Contains("CREATE"))
            {
                HelperActions.OnClick(addCompanyKnowledgeBaseBtn, driver);
                HelperActions.SendText(txtToSearchTxtB, driver, fieldvalue);
                HelperActions.selectOptionDropdownByText(wordIndicator, "Single Word", driver);
                // HelperActions.SelectDropDownText(wordIndicator,"Single Word",driver);
                HelperActions.selectOptionDropdownByText(wordPosition, "Any Word", driver);
                HelperActions.selectOptionDropdownByText(tag, tagName, driver);
                HelperActions.SendText(txtToReplace, driver, "TestAuto" + fieldvalue);
                HelperActions.OnClick(submitKnwledgeBase, driver);
                Thread.Sleep(1000);
                Assert.True(HelperActions.GetNotificationMessage(driver).Contains("Knowledgebase record already exists") || HelperActions.GetNotificationMessage(driver).Contains("Data created successfully"));
            }
            else if (action.Contains("UPDATE") || action.Contains("EDIT"))
            {
                //Filter Tag
                HelperActions.OnClick(tagFilterBtn, driver);
                Assert.True(HelperActions.ElementExists(companyKnowledgeBaseFilter, driver),"Not able to open tag filter in Company knowledgeBase");
                select = new SelectElement(driver.FindElement(companyKnowledgeBaseFilter));
                select.SelectByValue(tagName);
                for (i = 0; i < 5; i++)
                {
                    try
                    {
                        var element = driver.FindElement(By.XPath($"//td[text()='{fieldvalue}']//following-sibling::td/*[@class='editCompanyNameKnowledgebase']"));
                        jsDriver.ExecuteScript(highlightJavascript, new object[] { element });
                        element.Click();
                        break;
                    }
                    catch (Exception) { Thread.Sleep(1000); }
                }
                HelperActions.SendText(txtToSearchTxtB, driver, updatedvalue);
                HelperActions.SendText(txtToReplace, driver, "TestAuto" + updatedvalue);
                HelperActions.OnClick(submitKnwledgeBase, driver);
                Thread.Sleep(1000);
                Assert.True(HelperActions.GetNotificationMessage(driver).Contains("Data updated successfully")|| HelperActions.GetNotificationMessage(driver).Contains("Knowledgebase record already exists"));
            }
            else if (action.Contains("DELETE"))
            {
                //Filter Tag
                Thread.Sleep(1500);
                HelperActions.OnClick(tagFilterBtn, driver);
             
                Assert.True(HelperActions.ElementExists(companyKnowledgeBaseFilter, driver), "Not able to open tag filetr in Company knowledgeBase");
                select = new SelectElement(driver.FindElement(companyKnowledgeBaseFilter));
                var element = driver.FindElement(By.XPath($"//*[@id='filterValTag0'][@class='filterValue']//*[text()='{tagName}']"));
                jsDriver.ExecuteScript(highlightJavascript, new object[] { element });
                // select.SelectByValue([]);
                select.SelectByValue("[*]");
                Thread.Sleep(1000);
                ((IJavaScriptExecutor)driver).ExecuteScript("window.scrollTo(document.body.scrollHeight, 0)");
                HelperActions.OnClick(tagFilterBtn, driver);
                Assert.True(HelperActions.ElementExists(companyKnowledgeBaseFilter, driver), "Not able to open tag filetr in Company knowledgeBase");
                select = new SelectElement(driver.FindElement(companyKnowledgeBaseFilter));
                select.SelectByValue(tagName);
                
                ((IJavaScriptExecutor)driver).ExecuteScript("window.scrollTo(document.body.scrollHeight, 0)");
                for (i = 0; i < 5; i++)
                {
                    try
                    {
                        element = driver.FindElement(By.XPath($"//td[text()='{fieldvalue}']//following-sibling::td/*[@class='deleteCompanyNameKnowledgebase']"));

                        jsDriver.ExecuteScript(highlightJavascript, new object[] { element });
                        element.Click();
                        HelperActions.OnClick(confirmYes, driver);
                        HelperActions.GetNotificationMessage(driver).Contains("Data deleted successfully");
                        Thread.Sleep(1200);
                        driver.Url = driver.Url;
                        break;
                    }
                    catch (Exception) { Thread.Sleep(800); }
                }
            }
           
            if (HelperActions.ElementExists(closeBtn, driver))
                HelperActions.OnClick(closeBtn, driver);
            return new SettingsPage(driver);
        }
        public SettingsPage CRUDCompanyCleaning(string action)
        {
            string tagName = EnvironmentDataHelper.GetData("Tag", "CompanyKnowledgeBase");
            string hubtagName = EnvironmentDataHelper.GetData("HubTag", "CompanyKnowledgeBase");
            string tagName1 = EnvironmentDataHelper.GetData("Tag2", "CompanyKnowledgeBase");
            string hubtagName1 = EnvironmentDataHelper.GetData("HubTag2", "CompanyKnowledgeBase");
            action = action.ToUpper().Trim();
            if (action.Contains("ADD") || action.Contains("CREATE"))
            {
                HelperActions.OnClick(addCompanyCleaningBtn,driver);
                //searchTxtBtn
                HelperActions.selectOptionDropdownByText(tag, tagName,driver);
                HelperActions.selectOptionDropdownByText(hubTagDrpDwn, hubtagName, driver);
                
                HelperActions.OnClick(submitCompanyCleaningBtn, driver);
                Assert.True(HelperActions.GetNotificationMessage(driver).Contains("Tag is already defined") || HelperActions.GetNotificationMessage(driver).Contains("Data created successfully"));
            }
            else if (action.Contains("UPDATE") || action.Contains("EDIT"))
            {
                HelperActions.SendText(searchTxtBtn,driver, tagName);
                Thread.Sleep(800);
                //Filter Tag
                driver.FindElements(editCompanyCleaningBtn).ElementAt(0).Click();

                HelperActions.selectOptionDropdownByText(tag, tagName1, driver);
                HelperActions.selectOptionDropdownByText(hubTagDrpDwn, hubtagName1, driver);

                HelperActions.OnClick(submitCompanyCleaningBtn, driver);
                Assert.True(HelperActions.GetNotificationMessage(driver).Contains("Data updated successfully"));
            }
            else if (action.Contains("DELETE"))
            {
                //Filter Tag
                HelperActions.SendText(searchTxtBtn, driver, tagName1);
                Thread.Sleep(800);
                //Filter Tag
                driver.FindElements(deleteCompanyCleaningBtn).ElementAt(0).Click();
                HelperActions.OnClick(deleteYesBtn, driver);
                Assert.True(HelperActions.GetNotificationMessage(driver).Contains("Data deleted successfully"));
            }
           
            return new SettingsPage(driver);
        }
        public Boolean VerifyCompanyCleaning(string tagName,String behaviour)
        {
            bool Flag = false;
           for(int i=0;i<3;i++)
            try
            {
                HelperActions.SendText(searchTxtBtn, driver, tagName+" "+behaviour);
                Thread.Sleep(1000);
                var filteredvalue = driver.FindElement(By.XPath($"//td[contains(text(),'{tagName}')]//following-sibling::td[3]")).GetAttribute("innerText");
                Flag=filteredvalue.Contains(behaviour);
                break;
            }
            catch (NoSuchElementException) {Thread.Sleep(800);}
            return Flag;

        }
        public Boolean VerifyCompanyKnowledgeBase(string tagName, String fieldName)
        {
            SelectElement select;
            bool Flag = false;
            for(int i=0;i<5;i++)
            try
            {
                var jsDriver = (IJavaScriptExecutor)driver;
                var element = driver.FindElement(tagFilterBtn);
                string highlightJavascript = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color: red"";";
                jsDriver.ExecuteScript(highlightJavascript, new object[] { element });
                HelperActions.OnClick(tagFilterBtn, driver);
                Assert.True(HelperActions.ElementExists(companyKnowledgeBaseFilter, driver), "Not able to open tag filter in Company knowledgeBase");
                select= new SelectElement(driver.FindElement(companyKnowledgeBaseFilter));
                select.SelectByValue("[*]");
                HelperActions.OnClick(tagFilterBtn, driver);
                Assert.True(HelperActions.ElementExists(companyKnowledgeBaseFilter, driver), "Not able to open tag filter in Company knowledgeBase");
                select = new SelectElement(driver.FindElement(companyKnowledgeBaseFilter));
                select.SelectByValue(tagName);
                var webElemnt = driver.FindElement(By.XPath($"//td[text()='{fieldName}']//following-sibling::td[text()='{tagName}']"));
                Flag = webElemnt.Enabled || webElemnt.Displayed;
                break;
            }
            catch(Exception)
             {
         Thread.Sleep(800);
             }            
            return Flag;

        }

        public SettingsPage CRUDEncryptionKey(string action)
        {

            string keyName = EnvironmentDataHelper.GetData("KeyName", "EncryptionKey");
            string fileName = EnvironmentDataHelper.GetData("FileName", "EncryptionKey");
            string updatedkeyName = EnvironmentDataHelper.GetData("UpdatedKeyName", "EncryptionKey");
            string updatedfileName = EnvironmentDataHelper.GetData("UpdatedFileName", "EncryptionKey");
            action = action.ToUpper().Trim();
            if (action.Contains("ADD") || action.Contains("CREATE"))
            {
                HelperActions.OnClick(addExportEncrpBtn, driver);
                //searchTxtBtn
                HelperActions.SendText(keyNameTxtBox, driver, keyName);
                HelperActions.fileUpload(browseBtn, fileName, driver);
                HelperActions.OnClick(addExportFileBtn, driver);
                if(HelperActions.GetNotificationMessage(driver).Contains("already exists. Please provide a unique name"))
                    driver.Navigate().Refresh();
                else
                    Assert.True(HelperActions.GetNotificationMessage(driver).Contains("Encryption Key added successfully"));         
                Thread.Sleep(1400);
            }
            else if (action.Contains("UPDATE") || action.Contains("EDIT"))
            {
                if (SearchExportEncryptionKey(fileName))
                {
                    foreach(WebElement webElemnt in driver.FindElements(editExportEncyptionDataBtn))
                    {
                        if (webElemnt.GetAttribute("data-keyfilename").Contains(fileName))
                        {
                            HelperActions.OnClick(webElemnt, driver);
                            break;
                        }
                    }
                    Thread.Sleep(800);
                    //Filter Tag
                    HelperActions.SendText(keyNameTxtBox, driver, updatedkeyName);
                    HelperActions.fileUpload(browseBtn, updatedfileName, driver);
                    HelperActions.OnClick(addExportFileBtn, driver);
                    Assert.True(HelperActions.GetNotificationMessage(driver).Contains("Encryption Key updated successfully"));
                    Thread.Sleep(1400);
                }
                else
                {
                    Assert.Fail("No Encryption Key found to be updated");
                }
            }
            else if (action.Contains("DELETE"))
            {
                if (SearchExportEncryptionKey(updatedfileName))
                {
                    foreach (WebElement webElemnt in driver.FindElements(deleteExportEncyptionDataBtn))
                    {
                        if (webElemnt.GetAttribute("data-keyfilename").Equals(updatedfileName))
                        {
                            HelperActions.OnClick(webElemnt, driver);
                            HelperActions.OnClick(deleteYesBtn, driver);
                            break;
                        }
                    }
                    Assert.True(HelperActions.GetNotificationMessage(driver).Contains("Encryption Key deleted successfully"));
                    Thread.Sleep(1400);
                }
                else
                {
                    Assert.Fail("No Encryption Key found to be deleted");
                }
            }
            return new SettingsPage(driver);
        }

        public SettingsPage ValidatingEncryptionKey(string action)
        {
            string fileName = EnvironmentDataHelper.GetData("FileName", "EncryptionKey");
            string updatedfileName = EnvironmentDataHelper.GetData("UpdatedFileName", "EncryptionKey");
            action = action.ToUpper().Trim();
            if (action.Contains("ADD") || action.Contains("CREATE"))
            {
                Assert.True(SearchExportEncryptionKey(fileName), "Not able to find the created EncyptionKey");
            }
            else if (action.Contains("UPDATE") || action.Contains("EDIT"))
            {
                Assert.IsFalse(SearchExportEncryptionKey(fileName), "Able to find the Older name of EncyptionKey");
                Assert.IsTrue(SearchExportEncryptionKey(updatedfileName), "Not able to find the Updated EncyptionKey");
            }
            else if (action.Contains("DELETE"))
            {
                Assert.IsFalse(SearchExportEncryptionKey(fileName), "Able to find the created EncyptionKey Name");
                Assert.IsFalse(SearchExportEncryptionKey(updatedfileName), "Able to find the Updated EncyptionKey");
            }
                       
            return new SettingsPage(driver);
        }
        public Boolean SearchExportEncryptionKey(string fileName)
        {
            Boolean flag = false;
            Thread.Sleep(1000);
            HelperActions.SendText(searchEncryptionTxtBox, driver, fileName);
            foreach (var WebElemnt in driver.FindElements(filteredExportEncyptionData))
            {
                if (WebElemnt.GetAttribute("innerText").Equals(fileName))
                    {
                    flag = true;
                    break;
                }
            }
            return flag;
        }
        public SettingsPage DownloadEncryptionKey()
        {
            HelperActions.OnClick(MBSEncyptionKey, driver);
            Assert.True(HelperActions.fileExits("mbs_public_key.txt"));
            return new SettingsPage(driver);
        }
        public Boolean TemplateCreationConfigImport()
        {
            Boolean Flag = false;
            string fileName = EnvironmentDataHelper.GetData("FileNameConfig", "ImportProcessFileTemplate");
            string fileTemplateName = EnvironmentDataHelper.GetData("TemplateName", "ImportProcessFileTemplate");
            HelperActions.OnClick(addConfigImportProcess, driver);
            HelperActions.OnClick(addNewTemplateBtn, driver);
            HelperActions.OnClick(nextFileImportBtn, driver);
            HelperActions.fileUpload(importDataBrowserTxtBox, fileName,driver);
            HelperActions.SendText(templateNameTxtBox, driver, fileTemplateName);
            HelperActions.OnClick(hasHeaderChkBox, driver);
            Thread.Sleep(1000);
            HelperActions.OnClick(uploadFileNextBtn, driver);
            Thread.Sleep(1200);
            HelperActions.ElementExists(errorMessageTemplateName, driver);
            IWebElement Errmessage = driver.FindElement(errorMessageTemplateName);
            Flag = Errmessage.GetAttribute("innerText").Contains("already exists, please try again using a different name");
            return Flag;
        }

        public SettingsPage TogglingDataMappingTabs(String? tabName=null) 
        {
           
            if (!tabName.IsNullOrEmpty())
            {
                //IWebElement we = driver.FindElement(By.XPath($"//*[@id='myTab1']//*[@href='{tabName}']"));
                HelperActions.OnClick(driver.FindElement(By.XPath($"//*[@id='myTab1']//*[@href='#{tabName}']")), driver);
            }
            else
            {
            Dictionary<String, String> TabName=new Dictionary<String, String>();
            TabName.Add("#AlternateAddresses", "Company Name #2");
            TabName.Add("#ImportData", "Source Record ID");
            TabName.Add("#AdditionalFields", "National Provider ID");
            TabName.Add("#CustomIdentifiers", "Custom ID #1");
            TabName.Add("#EnhancedCleansing", "Full Address");
            TabName.Add("#ReferenceFields", "Passthrough Reference #1");
                foreach (var dic in TabName)
                {
                    HelperActions.OnClick(driver.FindElement(By.XPath($"//*[@id='myTab1']//*[@href='{dic.Key}']")), driver);
                    Thread.Sleep(600);
                    Assert.True(HelperActions.ElementExists(driver.FindElement(By.XPath($"//*[contains(text(),'{dic.Value}')]")), driver), "Page is not loading for " + dic.Key); ;
                }
                if(HelperActions.ElementExists(finishImportDataUploadBtn,driver,1))
                    HelperActions.OnClick(finishImportDataUploadBtn, driver);
                else if(HelperActions.ElementExists(finishImportDataUploadBtn2, driver,1))
                    HelperActions.OnClick(finishImportDataUploadBtn2, driver);
            }
                return new SettingsPage(driver);
        }
       
        //Template saved successfully.
        public Boolean ConfigurationCreationforImport()
        {
            Boolean Flag=false;
            string fileName = EnvironmentDataHelper.GetData("FileNameConfig", "ImportProcessFileTemplate");
            string templateName = EnvironmentDataHelper.GetData("TemplateName", "ImportProcessFileTemplate");
            string configurationName = EnvironmentDataHelper.GetData("ConfigurationName", "ImportProcessFileTemplate");
            string externalDataSource = EnvironmentDataHelper.GetData("ExternalDataSource", "ImportProcessFileTemplate");
            string sourceFolderPath = EnvironmentDataHelper.GetData("SourceFolderPath", "ImportProcessFileTemplate");
            string fileNamePattern = EnvironmentDataHelper.GetData("FileNamePattern", "ImportProcessFileTemplate");
            string postLoadAction = EnvironmentDataHelper.GetData("PostLoadAction", "ImportProcessFileTemplate");
            HelperActions.OnClick(addConfigImportProcess, driver);
            HelperActions.SendText(configurationNameTxtBox, driver, configurationName);
            HelperActions.selectOptionDropdownByText(fileTemplateDrpdwn,templateName, driver);
            HelperActions.selectOptionDropdownByText(externalDataStoreDrpdwn,"", driver,1);
            HelperActions.SendText(folderPathTxtBox, driver, sourceFolderPath);
            HelperActions.OnClick(validateBtn, driver);
            HelperActions.SendText(fileNamePatternTxtBox, driver, fileNamePattern);
            Thread.Sleep(800);
            driver.FindElement(saveBtn).Click();
            Thread.Sleep(3000);
            // HelperActions.OnClick(saveBtn, driver);
            Flag=HelperActions.GetNotificationMessage(driver).Contains("Confiuguration Name should be unique");
            return Flag;

        }//deleteConfigName
        public SettingsPage ConfigurationImportDeletion(String configurationName)
        {
            driver.Navigate().Refresh();
            HelperActions.SendText(searchConfigImportName, driver, configurationName);
            driver.FindElements(deleteConfigName).ElementAt(0).Click();
            HelperActions.OnClick(confirmYes, driver);
            Assert.True(HelperActions.GetNotificationMessage(driver).Contains("Import Configuration deleted successfully."));
            return new SettingsPage(driver);
        }
        public Boolean SearchingConfigName(String configurationName) {
            Boolean Flag = false;
            driver.Navigate().Refresh();
            HelperActions.SendText(searchConfigImportName, driver, configurationName);
            for(int i=0;i< driver.FindElements(filteredConfigName).Count;i++)
            {
                if (driver.FindElements(filteredConfigName).ElementAt(i).GetAttribute("innerText").Contains(configurationName))
                {
                    Flag = true;
                    break;
                }
            }
                
            return Flag;
        }


    }
}
    

