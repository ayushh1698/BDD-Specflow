using DataHub.Helper;
using DataHub.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using Service_Portal.Helper;
using Service_Portal.Utility;
using System;
using TechTalk.SpecFlow;

namespace DataHub.StepDefinitions
{
    [Binding]
    public class SettingStepDefinitions
    {
        private IWebDriver driver;
        private SettingsPage settingsPage;
        public Random random = new Random();
        private static int Random;
        public SettingStepDefinitions(IWebDriver driver)
        {
            this.driver = driver;
            settingsPage = new SettingsPage(driver);
            Random= random.Next(10, 99);
        }
        [Given(@"i am able to select Security Subtab ""([^""]*)""")]
        public void GivenIAmAbleToSelectSecuritySubtab(string SubtabName)
        {
            settingsPage.SelectingSecuritySubtab(SubtabName);
        }

        [Given(@"able to create new domain as ""([^""]*)""")]
        public void GivenAbleToCreateNewDomainAs(string testAuto)
        {
            settingsPage.CRUDDomainConfiguration(testAuto, "ADD");
        }

        [Then(@"i should be able to see the above ""([^""]*)""")]
        public void ThenIShouldBeAbleToSeeTheAbove(string testAuto)
        {
            Thread.Sleep(1800);
            settingsPage.SearchingUser(testAuto);
        }

        [Given(@"able to update the created user ""([^""]*)"" as ""([^""]*)""")]
        public void GivenAbleToUpdateTheCreatedUserAs(string testAuto,string fieldsToUpdate)
        {
            settingsPage.SearchingUser(testAuto);
            Thread.Sleep(1000);
            settingsPage.EditingUser(fieldsToUpdate);      
        }

        [Given(@"able to delete the created user as ""([^""]*)""")]
        public void GivenAbleToDeleteTheCreatedUserAs(string testAuto)
        {
            settingsPage.SearchingUser(testAuto);
            settingsPage.DeletingUser(testAuto);
        }

        [Then(@"i should be not be able to see the above ""([^""]*)""")]
        public void ThenIShouldBeNotBeAbleToSeeTheAbove(string testAuto)
        {
            Thread.Sleep(1500);
           settingsPage.SearchingUser(testAuto);
           settingsPage.ValidatingUserIsDeleted();
        }

        [Given(@"able to create new User as ""([^""]*)""")]
        public void GivenAbleToCreateNewUserAs(string testAuto)
        {
            settingsPage.AddingUser(testAuto);
        }

        [Given(@"able to update the created domain ""([^""]*)"" as ""([^""]*)""")]
        public void GivenAbleToUpdateTheCreatedDomainAs(string testDom, string updateTestDom)
        {
            settingsPage.CRUDDomainConfiguration(testDom, "UPDATE", updateTestDom);
        }

        [Given(@"able to delete the created domain as ""([^""]*)""")]
        public void GivenAbleToDeleteTheCreatedDomainAs(string testDom)
        {
            settingsPage.CRUDDomainConfiguration(testDom, "DELETE"); 
        }

        [Then(@"i should be able to see the above ""([^""]*)"" domain")]
        public void ThenIShouldBeAbleToSeeTheAboveDomain(string domainName)
        {
            settingsPage.ValidatingDomain(domainName);
        }

        [Then(@"i should be not be able to see the above ""([^""]*)"" domain")]
        public void ThenIShouldBeNotBeAbleToSeeTheAboveDomain(string domainName)
        {
            settingsPage.ValidatingDomain(domainName, false); 
        }


// DataHub Stepdefinitions

        [StepDefinition(@"i am able to click on ""([^""]*)"" tab")]
        public void GivenIAmAbleToClickOnTab(string SubtabName)
        {
            settingsPage.SelectingSettingsSubSubTabs(SubtabName);
        }

        [StepDefinition(@"i am able to navigate to ""([^""]*)"" tab")]
        public void ThenIAmAbleToNavigateToTab(string SubtabName)
        {
            settingsPage.SelectingDataHubSubtab(SubtabName);
            //Thread.Sleep(2000);
        }


        [Then(@"i am able to select Add button")]
        public void ThenIAmAbleToSelectAddButton()
        {
            settingsPage.ClickAddHubGroup();
        }


        [Then(@"i am able to enter required data")]
        public void ThenIAmAbleToEnterRequiredData()
        {
            //string groupName = ConfigProvider.Config.GROUPNAME;
            Assert.Fail(EnvironmentDataHelper.GetData("GROUPNAME", "DataHub"));
            settingsPage.AddingGroupName(EnvironmentDataHelper.GetData("GROUPNAME", "DataHub"));
        }

        [Then(@"i am able to click edit and enter new edit data")]
        public void ThenIAmAbleToClickEditAndEnterNewEditData()
        {
            settingsPage.ClickEditHubGroup(EnvironmentDataHelper.GetData("GROUPNAME", "DataHub"));
            settingsPage.AddingGroupName(EnvironmentDataHelper.GetData("EDITEDGROUPNAME", "DataHub"));
        }

        [Then(@"i am able to click delete and click confirm")]
        public void ThenIAmAbleToClickDeleteAndClickConfirm()
        {
            settingsPage.ClickOnDeleteAndConfirm(EnvironmentDataHelper.GetData("EDITEDGROUPNAME", "DataHub"));
        }



        [Then(@"i am able to save the data")]
        public void ThenIAmAbleToSaveTheData()
        {
            settingsPage.ClickOnSave();
        }

        [StepDefinition(@"i am able to search for added data existing")]
        public void ThenIAmAbleToSearchForAddedDataExisting()
        {
            //Thread.Sleep(3000);
            settingsPage.VerifyExisting(EnvironmentDataHelper.GetData("GROUPNAME", "DataHub"));
        }

        [Then(@"i am able to search for Edited data existing")]
        public void ThenIAmAbleToSearchForEditedDataExisting()
        {
            settingsPage.VerifyExisting(EnvironmentDataHelper.GetData("EDITEDGROUPNAME", "DataHub"));
        }


        [Then(@"i am able to search for Deleted data existing")]
        public void ThenIAmAbleToSearchForDeletedDataExisting()
        {
            settingsPage.VerifyDeletedExisting(EnvironmentDataHelper.GetData("EDITEDGROUPNAME", "DataHub"));
           // Assert.Pass(false);
        }


        //DataHub --> Hub Sources --> Source Settings tab
        [Then(@"i am able to select Add Hub Sources button")]
        public void ThenIAmAbleToSelectAddHubSourcesButton()
        {
            settingsPage.ClickOnAddHubSources();
        }

        [Then(@"i am able to enter Hub Sources Setting required data")]
        public void ThenIAmAbleToEnterHubSourcesSettingRequiredData()
        {
            string sourceName = EnvironmentDataHelper.GetData("SOURCENAME", "DataHub");
            settingsPage.EnterSourceName(sourceName);
            settingsPage.SelectSourcesLOBTag(EnvironmentDataHelper.GetData("LOBTagValue", "DataHub"));
            settingsPage.SelectSourcesHubGroup(EnvironmentDataHelper.GetData("HubGroupValue", "DataHub"));
            settingsPage.SelectSourcesDuplicate(EnvironmentDataHelper.GetData("DuplicateValue", "DataHub"));
            settingsPage.SelectSourcesHubAutoAcceptance(EnvironmentDataHelper.GetData("AutoAcceptanceValue", "DataHub"));
            settingsPage.SelectSourcesThirdPartyChkbx(EnvironmentDataHelper.GetData("ThirdPartyChkbxValue", "DataHub"));
            settingsPage.ClickOnSaveNext();

        }

        [Then(@"i am able to enter Hub Sources Match Rules required data")]
        public void ThenIAmAbleToEnterHubSourcesMatchRulesRequiredData()
        {
            settingsPage.selectMatchRulesThirdPartySources(EnvironmentDataHelper.GetData("MatchRulesThirdPartySourcesValue", "DataHub"));
            settingsPage.selectMatchRulesCredentials(EnvironmentDataHelper.GetData("MatchRulesCredentialsValue", "DataHub"));
            settingsPage.ClickonAddThirdPartyCredBtn();
            settingsPage.AddDescriptiontext(EnvironmentDataHelper.GetData("DescriptionValue", "DataHub"));
            settingsPage.SelectParameter(EnvironmentDataHelper.GetData("ParameterValue", "DataHub"));
            settingsPage.ClickAddMatchRule();
        }

        [Then(@"i am able to save Hub Sources data")]
        public void ThenIAmAbleToSaveHubSourcesData()
        {
            settingsPage.ClickOnSaveNext();
        }

        [Then(@"i am able to search Hub Sources added data")]
        public void ThenIAmAbleToSearchHubSourcesAddedData()
        {
            settingsPage.VerifyHubSourceExisting(EnvironmentDataHelper.GetData("SOURCENAME", "DataHub"));
        }

        [Then(@"i am able to select Edit Hub Sources button")]
        public void ThenIAmAbleToSelectEditHubSourcesButton()
        {
            settingsPage.ClickEditHubGroup(EnvironmentDataHelper.GetData("SOURCENAME", "DataHub"));
        }

        [Then(@"i am able to enter Edit new Hub Sources data")]
        public void ThenIAmAbleToEnterEditNewHubSourcesData()
        {
            settingsPage.SelectSourcesHubGroup(EnvironmentDataHelper.GetData("EditedHubGroupValue", "DataHub"));
            settingsPage.SelectSourcesHubAutoAcceptance(EnvironmentDataHelper.GetData("EditedAutoAcceptanceValue", "DataHub"));
            settingsPage.ClickOnSaveNext();
            settingsPage.ClickonAddThirdPartyCredBtn();
            settingsPage.AddDescriptiontext(EnvironmentDataHelper.GetData("DescriptionValue", "DataHub"));
            settingsPage.SelectParameter(EnvironmentDataHelper.GetData("EditedParameterValue", "DataHub"));
            settingsPage.ClickAddMatchRule();
        }

        [Then(@"i am able to search for Edited Hub Source data existing")]
        public void ThenIAmAbleToSearchForEditedHubSourceDataExisting()
        {
            settingsPage.VerifyHubSourceExisting(EnvironmentDataHelper.GetData("SOURCENAME", "DataHub"));
        }

        [Then(@"i am able to select Delete Hub Sources button")]
        public void ThenIAmAbleToSelectDeleteHubSourcesButton()
        {
            settingsPage.ClickOnDeleteAndConfirm(EnvironmentDataHelper.GetData("SOURCENAME", "DataHub"));
        }

        [Then(@"i am able to search for Deleted Hub Source data existing")]
        public void ThenIAmAbleToSearchForDeletedHubSourceDataExisting()
        {
            settingsPage.VerifyHubSourceExisting(EnvironmentDataHelper.GetData("SOURCENAME", "DataHub"));
        }



        [StepDefinition(@"i am able to click on Logout")]
        public void GivenIAmAbleToClickOnLogout()
        {
            settingsPage.ClickOnLogout();
        }


        [StepDefinition(@"i am logged out successfully")]
        public void ThenIAmLoggedOutSuccessfully()
        {
            Thread.Sleep(3000);
            settingsPage.ClickOnYesLogout();       
        }

   //Common tab-----------country groups
        [Given(@"i am able to select Common Subtab ""([^""]*)""")]
        public void GivenIAmAbleToSelectCommonSubtab(string SubTabName)
        {
            settingsPage.SelectingCommonSubtab(SubTabName);
        }

        [Given(@"able to create new Country group as ""([^""]*)""")]
        public void GivenAbleToCreateNewCountryGroupAs(string testAuto)
        {
            settingsPage.CRUDCountryGroups(testAuto+ Random, "ADD");
        }

        [Then(@"i should be able to see the above ""([^""]*)"" country group")]
        public void ThenIShouldBeAbleToSeeTheAboveCountryGroup(string countryGroupName)
        {
            settingsPage.ValidatingCountryGroup(countryGroupName+ Random);
        }

        [Given(@"able to update the created Country group ""([^""]*)"" as ""([^""]*)""")]
        public void GivenAbleToUpdateTheCreatedCountryGroupAs(string testCG, string updateTestCG)
        {
            Thread.Sleep(3000);
            settingsPage.CRUDCountryGroups(testCG + Random, "UPDATE", updateTestCG + Random);
        }

        [Given(@"able to delete the created Country group ""([^""]*)""")]
        public void GivenAbleToDeleteTheCreatedCountryGroup(string testCG)
        {
            Thread.Sleep(3000);
            settingsPage.CRUDCountryGroups(testCG + Random, "DELETE");
        }

        [Then(@"i should be not be able to see the above ""([^""]*)"" country group")]
        public void ThenIShouldBeNotBeAbleToSeeTheAboveCountryGroup(string countryGroupName)
        {
            settingsPage.ValidatingCountryGroup(countryGroupName+ Random, false);
        }

    //Tags tab--------

        [Given(@"able to create new Tags as ""([^""]*)""")]
        public void GivenAbleToCreateNewTagsAs(string testAuto)
        {
            Thread.Sleep(3000);
            settingsPage.CRUDTags(testAuto + Random, "ADD");
        }

        [Then(@"i should be able to see the above ""([^""]*)"" tags")]
        public void ThenIShouldBeAbleToSeeTheAboveTags(string tagName)
        {
            settingsPage.ValidatingTags(tagName+Random);
        }


        [Given(@"able to update the created Tags ""([^""]*)""")]
        public void GivenAbleToUpdateTheCreatedTags(string tagName)
        {
            Thread.Sleep(3000);
            settingsPage.CRUDTags(tagName+Random, "UPDATE");
        }

        [Given(@"able to delete the created Tags ""([^""]*)""")]
        public void GivenAbleToDeleteTheCreatedTags(string tagName)
        {
            Thread.Sleep(3000);
            settingsPage.CRUDTags(tagName + Random, "DELETE");
        }

        [Then(@"i should be not be able to see the above ""([^""]*)"" Tag")]
        public void ThenIShouldBeNotBeAbleToSeeTheAboveTag(string tagName)
        {
            settingsPage.ValidatingTags(tagName + Random, false);
        }

        //User Comments tab-----

        [Given(@"able to create new User Comments as ""([^""]*)""")]
        public void GivenAbleToCreateNewUserCommentsAs(string testUC)
        {
            Thread.Sleep(3000);
            settingsPage.CRUDUserComments(testUC + Random, "ADD");
        }

        [Then(@"i should be able to see the above ""([^""]*)"" User Comments")]
        public void ThenIShouldBeAbleToSeeTheAboveUserComments(string testUC)
        {
            settingsPage.ValidatingUserComments(testUC + Random);
        }

        [Given(@"able to update the created User Comments ""([^""]*)"" as ""([^""]*)""")]
        public void GivenAbleToUpdateTheCreatedUserCommentsAs(string testUC, string updateTestUC)
        {
            Thread.Sleep(3000);
            settingsPage.CRUDUserComments(testUC + Random, "UPDATE", updateTestUC + Random);
        }

        [Given(@"able to delete the created User Comments ""([^""]*)""")]
        public void GivenAbleToDeleteTheCreatedUserComments(string testUC)
        {
            Thread.Sleep(3000);
            settingsPage.CRUDUserComments(testUC+Random, "DELETE");
        }

        [Then(@"i should be not be able to see the above ""([^""]*)"" User Comments")]
        public void ThenIShouldBeNotBeAbleToSeeTheAboveUserComments(string testUC)
        {
            settingsPage.ValidatingUserComments(testUC + Random, false);
        }
        //CompanyKnolwdgeBase
        [Given(@"i am able to select company knowledgebase subtab ""([^""]*)""")]
        public void GivenIAmAbleToSelectCompanyKnowledgebaseSubtab(string TabName)
        {
            settingsPage.SelectingCompanyKnowledgeBaseSubtab(TabName);
        }


        [Given(@"should be able to perform (.*) operation with company knowledgeBase named (.*) as (.*)")]
        public void CrudOperationinCompanyKnowledge(String operationName,String name,String updateName)
        {
            settingsPage.CRUDCompanyKnowledgeBase(name, operationName,updateName);
        }

        [Then(@"i should be able to view/not able to view the above company knowldgebase (.*) according to operation (.*)")]
        public void verificationInCompanyKnowledgeBase(String fieldName, String operationName)
        {
            string tagName =EnvironmentDataHelper.GetData("Tag", "CompanyKnowledgeBase");
            operationName = operationName.Trim().ToUpper();
            if (operationName == "CREATE" || operationName == "ADD"|| operationName == "UPDATE" || operationName == "EDIT")
            {

                Assert.True(settingsPage.VerifyCompanyKnowledgeBase(tagName, fieldName), "Failed in validating the Filtered Company knowledge base after creation/Updation");
            }
            else
            {
                Assert.False(settingsPage.VerifyCompanyKnowledgeBase(tagName, fieldName), "Failed in validating the Filtered Company knowledge base after Deletion");
            }
        }
        [Given(@"should be able to perform (.*) operation in company cleaning")]
        public void CRUDOperationCompanyCleaning(string operationName)
        {
            settingsPage.CRUDCompanyCleaning(operationName);
        }

        [Then(@"i should be able to view/not able to view the above company cleaning according to operation (.*)")]
        public void ValidatingCompanyCleaning(string operationName)
        
        {
            string tagName, hubtagName;
            operationName = operationName.Trim().ToUpper();
            if (operationName == "CREATE" || operationName == "ADD")
            {
                tagName = EnvironmentDataHelper.GetData("Tag", "CompanyKnowledgeBase");
                hubtagName = EnvironmentDataHelper.GetData("HubTag", "CompanyKnowledgeBase");
                Assert.True(settingsPage.VerifyCompanyCleaning(tagName, hubtagName), "Failed in validating the Filtered Cleaned Company after creation");
            }
            else
            { 
                tagName = EnvironmentDataHelper.GetData("Tag2", "CompanyKnowledgeBase");
                hubtagName = EnvironmentDataHelper.GetData("HubTag2", "CompanyKnowledgeBase");
                if (operationName == "UPDATE")
                {
                    Assert.True(settingsPage.VerifyCompanyCleaning(tagName, hubtagName), "Failed in validating the Filtered Cleaned Company after Updating");
                }
                else if (operationName == "DELETE")
                {
                    Assert.False(settingsPage.VerifyCompanyCleaning(tagName, hubtagName), "Failed in validating the Filtered Cleaned Company After Deleting");
                }
            }
        }
        [Given(@"should be able to perform (.*) operation in encryption key")]
        public void CRUDOperationEncryptionKey(string operation)
        {
            settingsPage.CRUDEncryptionKey(operation);
        }

        [Then(@"i should be able to view/not able to view the above encryption key (.*)")]
        public void ValidatingEncryptionKey(string operation)
        {
            settingsPage.ValidatingEncryptionKey(operation);
        }
        [Then(@"i should be able to perform download operation in encryption key")]
        public void DownLoadEncryptionKey()
        {
            settingsPage.DownloadEncryptionKey();
        }


        
//Export Page Settings tab----
        [Given(@"able to update Export Page Settings with values")]
        public void GivenAbleToUpdateExportPageSettingsWithValues()
        {
            settingsPage.updateExportPageSettings();
        }



 //Export Destination tab------

        [Given(@"able to create new Export Destination as ""([^""]*)""")]
        public void GivenAbleToCreateNewExportDestinationAs(string ExportDestName)
        {
            Thread.Sleep(3000);
            settingsPage.CRUDExportDestination(ExportDestName,"ADD");
        }
        [Then(@"i should be able to see the above ""([^""]*)"" Export Destination")]
        public void ThenIShouldBeAbleToSeeTheAboveExportDestination(string ExportDestName)
        {
            settingsPage.ValidatingExportDestination(ExportDestName);
        }
        [Given(@"able to update the created Export Destination ""([^""]*)"" as ""([^""]*)""")]
        public void GivenAbleToUpdateTheCreatedExportDestinationAs(string ExportDestName, string updatedExportDestName)
        {
            Thread.Sleep(3000);
            settingsPage.CRUDExportDestination(ExportDestName, "UPDATE", updatedExportDestName);
        }
        [Given(@"able to delete the created Export Destination ""([^""]*)""")]
        public void GivenAbleToDeleteTheCreatedExportDestination(string updatedExportDestName)
        {
            Thread.Sleep(3000);
            settingsPage.CRUDExportDestination(updatedExportDestName, "DELETE");
        }
        [Then(@"i should be not be able to see the above ""([^""]*)"" Export Destination")]
        public void ThenIShouldBeNotBeAbleToSeeTheAboveExportDestination(string updatedExportDestName)
        {
            settingsPage.ValidatingExportDestination(updatedExportDestName, false);
        }




    }
}
