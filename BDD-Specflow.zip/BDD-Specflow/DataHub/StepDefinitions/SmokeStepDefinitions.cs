using DataHub.Pages;
using OpenQA.Selenium;
using Service_Portal.Helper;
using Service_Portal.Pages;
using Service_Portal.Utility;
using System;
using TechTalk.SpecFlow;

namespace DataHub.StepDefinitions
{
    [Binding]
    public class SmokeStepDefinitions
    {
        private IWebDriver driver;
        private HomePage homePage;
        private SettingsPage settingsPage;
        public SmokeStepDefinitions(IWebDriver driver)
        {
            this.driver = driver;
            homePage = new HomePage(driver);
            settingsPage = new SettingsPage(driver);

        }
        [Given(@"i am logged in successfully")]
        public void GivenIAmLoggedInSuccessfully()
        {
            string userId = ConfigProvider.Config.USER_ID;
            string pwd = ConfigProvider.Config.PWD;
            LoginPage loginPage = new LoginPage(driver);
            new LoginPage(driver).ValidatingLoginPage().SelectOktaLogin();
            new OktaAutheticationPage(driver).SigninginOkta(userId, pwd);
            Thread.Sleep(5000);
        }

        [Given(@"i am able to see all the tabs in HomePage")]
        public void GivenIAmAbleToSeeAllTheTabsInHomePage()
        {
            homePage.ValidationOfEachTab();
        }
        [Given(@"i login into the url ""([^""]*)""")]
        public void GivenILoginIntoTheUrl(string portaltype)
        {
            string url = "";
            if (portaltype.ToUpper().Contains("DATAHUB QA"))
                url = ConfigProvider.Config.QA_URL;

            driver.Url = url;
            Thread.Sleep(3000);
            
        }

        [When(@"i should be able to select settings subtab ""([^""]*)""")]
        public void SelectingSettingSubTab(string subtabname)
        {
            var subtabs = (subtabname.Trim().Split(','));
            foreach (var tab in subtabs)
                homePage.SelectingSettingSubTab(tab);
        }

        [Then(@"i should be able to click on ""([^""]*)"" tabs")]
        public void ThenIShouldBeAbleToClickOnTabs(string tabname)
        {
            var subtabs = (tabname.Trim().Split(','));
            foreach (var tab in subtabs)
                settingsPage.SelectingSettingsSubSubTabs(tab);
        }

        [Then(@"i am able see (.*)")]
        public void ThenIAmAbleSeeDataHubPage(string pageName)
        {
            Console.WriteLine(pageName+" Page Verified");
        }
       
        [When(@"i click on tab ""([^""]*)""")]
        public void WhenIClickOnTab2(string tabName)
        {
            homePage.ClickingTab(tabName);
        }

        [When(@"i click on tabs (.*)")]
        public void WhenIClickOnTabsReports(string TabName)
        {
            homePage.ClickingTab(TabName);
        }

        [Then(@"i should be able to select subtabs (.*) under (.*)")]
        public void ThenIShouldBeAbleToSelect(string SubTabName, string TabName)
        {
            TabName = TabName.Replace($"\"", "");
            var subtabs = (SubTabName.Trim().Split(','));

            switch (TabName.ToUpper().Trim())
            {
                case "REPORTS":
                    foreach (var tab in subtabs)
                        homePage.SelectingReportsSubTab(tab);
                    break;
                case "INTEGRATIONS":
                    foreach (var tab in subtabs)
                        homePage.SelectingIntegrationSubTab(tab);
                    break;
                case "WORK QUEUES":
                    foreach (var tab in subtabs)
                        homePage.SelectingWorkQueuesSubTab(tab);
                    break;
                default:
                    Console.WriteLine("Wrong Input");
                    break;

            }
        }
           

        }
    

}