﻿using DataHub.Helper;
using DataHub.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using Service_Portal.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace DataHub.StepDefinitions
{
    [Binding]
    public class ImportFileStepDefinitions
    {
        private IWebDriver driver;
        private HomePage homePage;
        private SettingsPage settingsPage;
        private IntegrationsPage integrationsPage;
        private WorkQueuesPage workQueuesPage;
        private Random random;
        public static String updatedVal;
        public static String updateFileName;
        public ImportFileStepDefinitions(IWebDriver driver)
        {
            this.driver = driver;
           homePage = new HomePage(driver);
           settingsPage = new SettingsPage(driver);
           integrationsPage = new IntegrationsPage(driver);
           workQueuesPage = new WorkQueuesPage(driver);
           random = new Random();

        }
        [Given(@"i am able to import ""([^""]*)"" in integrations")]
        public void ImportFileInIntegrations(string excel)
        {
            updatedVal = random.Next(101,999) + DateTime.Now.ToString("MMMMddyy");
           
            string fileName = EnvironmentDataHelper.GetData("FileNameForImportIntegration" , "ImportProcessFileTemplate");
            updateFileName = fileName.Split('.')[0]+ updatedVal+ "."+fileName.Split('.')[1];
            string sheetName = EnvironmentDataHelper.GetData("SheetNameForImportIntegration" , "ImportProcessFileTemplate");
            HelperActions.UpdatingExcel("SrcRecordId", sheetName, fileName, updateFileName);
            HelperActions.UpdatingExcelName(fileName, updateFileName);
            integrationsPage.ImportingData(updateFileName, sheetName);
            settingsPage.TogglingDataMappingTabs();

        }
        [Given(@"i am able to see imported data sheet")]
        public void ValidatingImportedData()
        {
            string sheetName = EnvironmentDataHelper.GetData("SheetNameForImportIntegration", "ImportProcessFileTemplate");
            integrationsPage.VerfyingImportedNotifications(updateFileName, sheetName);
        }
       
        [When(@"i filter ""([^""]*)"" and ""([^""]*)"" in Entity Stewardship")]
        public void WhenIFilterAndInEntityStewardship(string status, string source)
        {
            string statusType = EnvironmentDataHelper.GetData("StatusType", "ImportProcessFileTemplate");
            string filterType = EnvironmentDataHelper.GetData("FilterTypeEntityStewardShip", "ImportProcessFileTemplate");    
            workQueuesPage.FilteringStatusEntityStewardship(statusType);
            workQueuesPage.RemovingEntityStewardshipFilters();
            workQueuesPage.Filtering2ndFilterEntityStewardship(filterType, updateFileName);
        }

        [Then(@"i am able to see imported data in Entity Stewardship")]
        public void ThenIAmAbleToSeeImportedDataInEntityStewardship()
        {
            String elmCount = EnvironmentDataHelper.GetData("ImportedElementCount", "ImportProcessFileTemplate");
            Assert.True(workQueuesPage.ValidtingFilterdValueEntityStewardship(updateFileName.Split("\\")[1], int.Parse(elmCount)),"Not able to find the imported file in Entity Stewardship");
        }



        [Given(@"i am able able to see config import tab , click Add config import List & create sample file template")]
        public void AddImportFileTemplate()
        {
        AddImportFileTemplate:
            Boolean Flag = settingsPage.TemplateCreationConfigImport();
            if (Flag)
            {
                string fileTemplateName = EnvironmentDataHelper.GetData("TemplateName", "ImportProcessFileTemplate");
                integrationsPage.DeletingImportTemplate(fileTemplateName);
                homePage.SelectingSettingSubTab("Portal");
                settingsPage.SelectingSettingsSubSubTabs("Data Integration");
                goto AddImportFileTemplate;
            }
            settingsPage.TogglingDataMappingTabs();

        }

        [Then(@"i should be able to see the above file template in config import process")]
        public void ValidatingAddedFileTemplate()
        {
            Assert.True(HelperActions.GetNotificationMessage(driver).Contains("Template saved successfully."));
        }
        [Given(@"able to create config import file")]
        public void GivenAbleToCreateConfigImportFile()
        {
           ConfigImportCreation:
            Boolean Flag=settingsPage.ConfigurationCreationforImport();
            if (Flag) {
                string configurationName = EnvironmentDataHelper.GetData("ConfigurationName", "ImportProcessFileTemplate");
                settingsPage.ConfigurationImportDeletion(configurationName);
                goto ConfigImportCreation;
            }
        }

        [Then(@"i should be able to see the created config import file")]
        public void ThenIShouldBeAbleToSeeTheCreatedConfigImportFile()
        {
            string configurationName = EnvironmentDataHelper.GetData("ConfigurationName", "ImportProcessFileTemplate");
            Assert.True(settingsPage.SearchingConfigName(configurationName),"Not able to find the created Config import File");
        }
        [When(@"i tried deleting the created config import")]
        public void DeletingTheCreatedConfigImport()
        {
            string configurationName = EnvironmentDataHelper.GetData("ConfigurationName", "ImportProcessFileTemplate");
            settingsPage.ConfigurationImportDeletion(configurationName);
        }

        [Then(@"i should be  not able to see the created config import file")]
        public void ValidatingConfigImportFile()
        {
            string configurationName = EnvironmentDataHelper.GetData("ConfigurationName", "ImportProcessFileTemplate");
            Assert.False(settingsPage.SearchingConfigName(configurationName), "Able to find the deleted Config import File");

        }




    }
}
