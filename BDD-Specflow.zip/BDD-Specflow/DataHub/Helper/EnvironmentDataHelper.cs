﻿using Microsoft.Extensions.Configuration;
using System.Configuration;

namespace DataHub.Helper
{
    public static class EnvironmentDataHelper
    {
        private static IConfigurationSection appSettings;
        private static object appLock=new object();
        private static void Init(string SectionName)
        {
            if (SectionName == null) { SectionName = "Common"; }
            var config = new ConfigurationBuilder().AddJsonFile("TestData/TestData.json").AddEnvironmentVariables().Build();
            appSettings = config.GetSection(SectionName);
        }
        public static string GetData(string key,string SectionName=null)
        {
            string result = null;
            if(appSettings==null)
            {
                lock (appLock)
                {
                    Init(SectionName);
                }
            }
            if (appSettings != null)
            {
               result = appSettings[key];
            }
            return result;
        }
    }
}

