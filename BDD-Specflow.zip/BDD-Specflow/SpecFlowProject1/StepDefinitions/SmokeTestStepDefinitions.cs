using OpenQA.Selenium;
using Service_Portal.Pages;
using Service_Portal.Utility;

namespace Service_Portal.StepDefinitions
{
    [Binding]
    public sealed class SmokeTestStepDefinitions
    {
        private IWebDriver driver;
        private SettingsPage settingsPage;
        private LoginPage loginPage;
        private HomePage homePage;
        private ExportDataPage exportdataPage;
        private DashboardPage dashboardPage;
        private OktaAutheticationPage oktaAutheticationPage;

        public SmokeTestStepDefinitions(IWebDriver driver)
        {
            this.driver = driver;
            settingsPage = new SettingsPage(driver);
            loginPage = new LoginPage(driver);
            homePage = new HomePage(driver);
            exportdataPage= new ExportDataPage(driver);
            dashboardPage = new DashboardPage(driver);
            oktaAutheticationPage = new OktaAutheticationPage(driver);

        }
        [Given(@"i am logged in successfully")]
        public void GivenIAmLoggedInSuccessfully()
        {
            loginPage = loginPage.ValidatingLoginPage();
            oktaAutheticationPage = loginPage.SelectOktaLogin();
            string userId = ConfigProvider.Config.USER_ID;
            string pwd = ConfigProvider.Config.PWD;
            oktaAutheticationPage.SigninginOkta(userId, pwd);
            Thread.Sleep(5000);
        }

        [Given(@"i am able to see all the tabs in HomePage")]
        public void GivenIAmAbleToSeeAllTheTabsInHomePage()
        {
            homePage.ValidationOfEachTab();
        }
        [When(@"i click on tab ""([^""]*)""")]
        public void WhenIClickOnTab(string tabName)
        {
            homePage.ClickingTab(tabName);

        }

        [When(@"i am able to see settings subtabs ""([^""]*)""")]
        public void WhenIAmAbleToSeeSettingsSubtabs(string subTabs)
        {
            var subtabs = (subTabs.Trim().Split(','));
            foreach (var tab in subtabs)
                homePage.SelectingSettingSubTab(tab);
        }
        
        [Given(@"i login into the url ""([^""]*)""")]
        public void GivenILoginIntoTheUrl(string portaltype)
        {
            string url = "";
            if (portaltype.ToUpper().Contains("TRAINING"))
                url = ConfigProvider.Config.TRAINING_URL;
            else if (portaltype.ToUpper().Contains("PROD"))
                url = ConfigProvider.Config.PROD_URL;
            else if (portaltype.ToUpper().Contains("DEV"))
                url = ConfigProvider.Config.DEV_URL;
            else if (portaltype.ToUpper().Contains("UAT"))
                url = ConfigProvider.Config.UAT_URL;
            driver.Url = url;
            Thread.Sleep(3000);
        }

        [When(@"i should be able to click on settings subtab ""([^""]*)""")]
        public void WhenIShouldBeAbleToClickOnSettingsSubtab(string tabName)
        {
            homePage.SelectingSettingSubTab(tabName);
        }
        [Then(@"i should be able to click on ""([^""]*)"" tabs")]
        public void ThenIShouldBeAbleToViewOnTabs(string subTabs)
        {
            String[] subtabs = subTabs.Split(",");
            foreach (String tab in subtabs)
                settingsPage.SelectingSettingsSubSubTabs(tab);
        }

        [Then(@"i am able to see Reports subtabs ""([^""]*)""")]
        public void WhenIAmAbleToSeeReportsSubtabs(string subTabs)
        {
            String[] subtabs = subTabs.Split(",");
            foreach (String tab in subtabs)
            {
                homePage.SelectingReportsSubTab(tab);
            }
        }

        [Then(@"i am able to see Complaince subtabs ""([^""]*)""")]
        public void WhenIAmAbleToSeeComplainceSubtabs(string subTabs)
        {
            String[] subtabs = subTabs.Split(",");
            foreach (String tab in subtabs)
                homePage.SelectingComplainceSubTab(tab);
        }

        [Then(@"i am able to see Prospecting subtabs ""([^""]*)""")]
        public void WhenIAmAbleToSeeProspectingSubtabs(string subTabs)
        {
            String[] subtabs = subTabs.Split(",");
            foreach (String tab in subtabs)
                homePage.SelectingProspectingSubTab(tab);
        }

        [Then(@"i am able to see Data Stewardship subtabs ""([^""]*)""")]
        public void WhenIAmAbleToSeeDataStewardshipSubtabs(string subTabs)
        {

            String[] subtabs = subTabs.Split(",");
            foreach (String tab in subtabs)
                homePage.SelectingDataStewardShipSubTab(tab);
        }
        [Then(@"i am able to see Export Data subtabs ""([^""]*)""")]
        public void ThenIAmAbleToSeeExportDataSubtabs(string ExportSubtabs)
        {
            String[] subtabs = ExportSubtabs.Split(",");
            foreach (String tab in subtabs)
                exportdataPage.SelectingExportSubTabs(tab);

        }
        [Then(@"i am able to see Dashboard statistics")]
        public void ThenIAmAbleToSeeDashboardStatistics()
        {
            dashboardPage.ValidatingRespectiveTables();
        }
        [Then(@"i am able to see Import data page")]
        public void ThenIAmAbleToSeeImportDataPage()
        {
            homePage.ValidatingImportPage();
        }




    }
}
