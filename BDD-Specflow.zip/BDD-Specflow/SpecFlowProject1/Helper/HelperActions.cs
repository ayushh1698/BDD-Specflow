﻿using AventStack.ExtentReports.Utils;
using Microsoft.Office.Interop.Excel;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.DevTools.V85.IndexedDB;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SharpCompress.Common;
using System.Data;
using System.Linq.Expressions;
using System.Reflection;
using static System.Net.Mime.MediaTypeNames;
using xl = Microsoft.Office.Interop.Excel;
using System.Data.OleDb;
using System.Data;
using MongoDB.Driver.Core.Configuration;
using System;

namespace Service_Portal.Helper
{
    public static class HelperActions
    {

        public static void OnClick(By WebElement, IWebDriver driver)
        {
            Boolean flag = false;
            WebDriverWait Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(45));
            for (int i = 0; i < 10; i++)
            {
                try
                {
                    IWebElement webElement = driver.FindElement(WebElement);
                    Wait.Until(d => webElement.Displayed || webElement.Enabled);
                    IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                    executor.ExecuteScript("arguments[0].click();", webElement);
                    flag = true;
                    break;
                }
                catch (Exception)
                {
                    Thread.Sleep(1000);
                }
            }
            Assert.IsTrue(flag, "Not able to find the element" + WebElement);
        }
        public static void OnClick(IWebElement webElement, IWebDriver driver)
        {
            Boolean flag = false;
            WebDriverWait Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(45));
            for (int i = 0; i < 10; i++)
            {
                try
                {
                    Wait.Until(d => webElement.Displayed || webElement.Enabled);
                    IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
                    executor.ExecuteScript("arguments[0].click();", webElement);
                    flag = true;
                    break;
                }
                catch (Exception e)
                {
                    Thread.Sleep(1000);
                }
            }
            Assert.IsTrue(flag, "Not able to find the element" + webElement);
        }
        public static void SendText(params By[] WebElement)
        {
          //  WebDriverWait Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(35));
            for (int i = 0; i < 5; i++)
            {
              /*  try
                {
                    IWebElement webElement = driver.FindElement(WebElement[0]);
                    Wait.Until(d => webElement.Displayed || webElement.Enabled);
                    webElement.SendKeys(Keys.Control + "A");
                    webElement.SendKeys(Text);
                    break;
                }
                catch (Exception)
                {
                    Thread.Sleep(800);
                }*/
            }
        }
        public static void SendText(By WebElement, IWebDriver driver, string? Text)
        {
            WebDriverWait Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(35));
            for (int i = 0; i < 5; i++)
            {
                try
                {
                    IWebElement webElement = driver.FindElement(WebElement);
                    Wait.Until(d => webElement.Displayed || webElement.Enabled);
                    webElement.SendKeys(Keys.Control + "A");
                    webElement.SendKeys(Text);
                    break;
                }
                catch (Exception)
                {
                    Thread.Sleep(800);
                }
            }
        }

        public static void SendText(IWebElement webElement, IWebDriver driver, string? Text)
        {
            WebDriverWait Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(35));
            for (int i = 0; i < 5; i++)
            {
                try
                {
                    Wait.Until(d => webElement.Displayed || webElement.Enabled);
                    webElement.Clear();
                    webElement.SendKeys(Keys.Control + "A");
                    webElement.SendKeys(Text);
                    break;
                }
                catch (Exception)
                {
                    Thread.Sleep(800);
                }
            }
        }
        public static void SelectDropDownCheckbx(By WebElement, string option, IWebDriver driver)
        {
            OnClick(WebElement, driver);
            Boolean Flag = false;
            string WebelemntXpath = "//*[contains(text(),'" + option + "')]";
            for (int i = 0; i < 2; i++)
            { try
                {
                    IList<IWebElement> selectElements = driver.FindElements(By.XPath(WebelemntXpath));
                    selectElements[1].Click();
                    OnClick(WebElement, driver);
                    Flag = true;
                    break;
                }
                catch (StaleElementReferenceException)
                {
                    Thread.Sleep(1000);
                }
            }
            Assert.IsTrue(Flag, "Not able to Select Checkbox Dropdown");

        }
        public static void SelectDropDownFirstOption(By WebElement, IWebDriver driver)
        {
            OnClick(WebElement, driver);
            IWebElement webElement = driver.FindElement(WebElement);
            for (int i = 0; i < 2; i++)
            {
                webElement.SendKeys(Keys.ArrowDown);
            }
            webElement.SendKeys(Keys.Enter);
        }
        public static Boolean ElementExists(By WebElement, IWebDriver driver,int a=45)
        {
            Boolean Flag = false;
            WebDriverWait Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(a));
            for (int i = 0; i < 5; i++)
            {
                try
                {
                    IWebElement webElement = driver.FindElement(WebElement);
                    Wait.Until(d => webElement.Displayed || webElement.Enabled);
                    Flag = true;
                    break;
                }
                catch (Exception)
                {
                    Thread.Sleep(1000);
                }
            }
            return Flag;
        }
        public static Boolean ValidatingInternalServerPage(By WebElement, IWebDriver driver)
        {
            Boolean Flag = false;
            WebDriverWait Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(5));
            for (int i = 0; i < 3; i++)
            {
                try
                {
                    IWebElement webElement = driver.FindElement(WebElement);
                    Wait.Until(d => webElement.Displayed || webElement.Enabled);
                    Flag = true;
                    break;
                }
                catch (Exception)
                {
                    Thread.Sleep(500);
                }
            }
            return Flag;
        }
        public static Boolean ElementExists(IWebElement webElement, IWebDriver driver)
        {
            Boolean Flag = false;
            WebDriverWait Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(45));
            for (int i = 0; i < 5; i++)
            {
                try
                {
                    Wait.Until(d => webElement.Displayed || webElement.Enabled);
                    Flag = true;
                    break;
                }
                catch (Exception)
                {
                    Thread.Sleep(1000);
                }
            }
            return Flag;
        }
        public static string GetNotificationMessage(IWebDriver driver)
        {
            string text = null;
            for (int i = 0; i < 5; i++)
            {
                try
                {
                    text = driver.FindElement(By.XPath("//span[@data-notify='message']")).GetAttribute("innerText");
                    break;
                }
                catch (NoAlertPresentException) { Thread.Sleep(1200); }
            }
            return text;
        }
        public static bool WebElementWait(By WebElement, IWebDriver driver)
        {
            bool flag = false;
            try
            {
                WebDriverWait Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
                IWebElement webElement = driver.FindElement(WebElement);
                Wait.Until(d => webElement.Displayed || webElement.Enabled);
                if (webElement.Displayed && webElement.Enabled)
                {
                    Thread.Sleep(1000);
                    return flag = true;
                }
                else
                    return flag = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return flag;
        }


        public static void selectOptionDropdownByText(By WebElement, string option, IWebDriver driver, int? index = 0)
        {
            driver.FindElement(WebElement).Click();
            IWebElement element = driver.FindElement(WebElement);
            SelectElement select = new SelectElement(element);
            if (!option.IsNullOrEmpty())
                select.SelectByText(option,true);
            //else if(option.IsNullOrEmpty())
                   // return;
            else if(option.IsNullOrEmpty() && index==null)
                return;
            else
                select.SelectByIndex((int)index);
        }

        public static void selectCheckboxInDropdown(string xpath, string option, IWebDriver driver)
        {
            // String xpath = "//span[@class='multiselect-selected-text']";
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            executor.ExecuteScript("arguments[0].style.border = '3px solid yellow'", driver.FindElement(By.XPath(xpath)));
            executor.ExecuteScript("arguments[0].click();", driver.FindElement(By.XPath(xpath)));


            if (option.Contains(";"))
            {
                int n = option.Split(";").Length;
                for (int i = 0; i < n; i++)
                {
                    Thread.Sleep(2000);
                    String selectValuesCheckBox = option.Split(";")[i];
                    driver.FindElement(By.XPath("//label[@class='checkbox' and text()=' " + selectValuesCheckBox + "']")).Click();
                    executor.ExecuteScript("arguments[0].click();", driver.FindElement(By.XPath(xpath)));
                    // if (i == n)
                    // driver.FindElement(By.XPath(xpath)).SendKeys(Keys.Tab);
                }
            }
            else if (driver.FindElement(By.XPath("(*//input[@type='checkbox' and @value='multiselect-all'])[1]")).Displayed)
            {//select all
                Thread.Sleep(2000);
                driver.FindElement(By.XPath("(*//input[@type='checkbox' and @value='multiselect-all'])[1]")).Click();
            }
            else
            {
                Thread.Sleep(2000);
                driver.FindElement(By.XPath("//label[@class='checkbox' and text()=' " + option + "']")).Click();
            }
        }
        public static void selectRadioBtnInDropdown(By webelement, string option, IWebDriver driver)
        {
            // String xpath = "//span[@class='multiselect-selected-text']";
            OpenQA.Selenium.Interactions.Actions action = new OpenQA.Selenium.Interactions.Actions(driver);
            IJavaScriptExecutor executor = (IJavaScriptExecutor)driver;
            executor.ExecuteScript("arguments[0].style.border = '3px solid yellow'", driver.FindElement(webelement));
            executor.ExecuteScript("arguments[0].click();", driver.FindElement(webelement));
            IWebElement searchTxt = driver.FindElement(By.XPath("//*[contains(@id,'divmsImportProcessId2')]//*[@class='form-control multiselect-search']"));
            Thread.Sleep(2000);
            if (option.Contains(";"))
            {
                int n = option.Split(";").Length;
                for (int i = 0; i < n; i++)
                {
                    Thread.Sleep(2000);
                    
                    searchTxt.SendKeys(option);
                    String selectValuesCheckBox = option.Split(";")[i];
                    if (!driver.FindElement(By.XPath($"//*[@class='multiselect-container dropdown-menu']//label[@class='radio'][contains(text(),'{option}')]")).Selected)
                        driver.FindElement(By.XPath($"//*[@class='multiselect-container dropdown-menu']//label[@class='radio'][contains(text(),'{option}')]/input")).Click();
                    // if (i == n)
                    // driver.FindElement(By.XPath(xpath)).SendKeys(Keys.Tab);
                }
            }
            else if (!option.IsNullOrEmpty())
            {//select all
                searchTxt.SendKeys(option);
                Thread.Sleep(1000);
                if (!driver.FindElement(By.XPath($"//*[@class='multiselect-container dropdown-menu']//label[@class='radio'][contains(text(),'{option}')]")).Selected)
                {
                    action.KeyDown(Keys.Tab).Build();
                    action.KeyDown(Keys.Enter).Perform();
                }
                else
                    action.KeyDown(Keys.Tab).Perform();
            }
            Thread.Sleep(2000);
        }
        public static void fileUpload(By WebElement, string filePath, IWebDriver driver)
        {
            WebDriverWait Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(45));
            IWebElement webElement = driver.FindElement(WebElement);
            Wait.Until(d => webElement.Displayed || webElement.Enabled);
            Thread.Sleep(1000);
            webElement.SendKeys(System.AppDomain.CurrentDomain.BaseDirectory + "TestData\\" + filePath);
        }
        public static Boolean fileExits(string fileName, string? filepath = null)
        {
            Boolean Flag = false;
            Thread.Sleep(2000);
            if (filepath.IsNullOrEmpty())
                filepath = System.AppDomain.CurrentDomain.BaseDirectory + "Downloads\\";
            String FilePath = filepath + fileName;
            Flag = File.Exists(FilePath);
            return Flag;
        }
        public static void UpdatingExcel(String fieldName, String? Sheetname, String ExcelName,String updatedValue )
        {

            if(Sheetname.IsNullOrEmpty())
                Sheetname = "Sheet1";
            String ExcelPath = System.AppDomain.CurrentDomain.BaseDirectory + "TestData\\"+ExcelName;
            System.Data.OleDb.OleDbConnection MyConnection;
            System.Data.OleDb.OleDbCommand myCommand = new System.Data.OleDb.OleDbCommand();
            //String constr = String.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + ExcelPath + "';Extended Properties='Excel 12.0 Xml;HDR=YES;IMEX=1'") ;
            String constr = String.Format(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + ExcelPath + "';Extended Properties='Excel 12.0 Xml;HDR=YES;'") ;
            MyConnection = new System.Data.OleDb.OleDbConnection(constr);
            //MyConnection.
            MyConnection.Open();
            myCommand.Connection = MyConnection;
            String sql = "Update ["+ Sheetname + "$] SET "+ fieldName + " = Replace("+ fieldName + ",'Auto' ,'"+ updatedValue + "') Where "+fieldName+"  IS NOT NULL";
            myCommand.CommandText = sql;
            var res=myCommand.ExecuteNonQuery();
            MyConnection.Close();
        }
        public static void UpdatingExcelName(String oldName,String newName)
        {
            String oldExcelPath = System.AppDomain.CurrentDomain.BaseDirectory + "TestData\\" + oldName;
            String newExcelPath = System.AppDomain.CurrentDomain.BaseDirectory + "TestData\\" + newName;
            File.Delete(newExcelPath); // Delete the existing file if exists
            File.Move(oldExcelPath, newExcelPath);
            File.Delete(oldExcelPath);

        }
    }
   
}
     

