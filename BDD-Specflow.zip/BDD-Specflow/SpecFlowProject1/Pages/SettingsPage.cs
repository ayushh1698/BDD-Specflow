﻿using NUnit.Framework;
using OpenQA.Selenium;
using Service_Portal.Helper;
using System.Text.RegularExpressions;

namespace Service_Portal.Pages
{
    internal class SettingsPage
    {
        private IWebDriver driver;
        public SettingsPage(IWebDriver driver) => this.driver = driver;

        //Portal
        protected By generalTab = By.Id("IdFeatureTab");
        protected By securityTab = By.Id("IdSecurityTab");
        protected By commonTab = By.Id("IdCommonTab");
        protected By countryGroupHeader = By.XPath("//header//*[contains(text(),'Country Group')]");
        protected By dataIntegrationTab = By.Id("IdDataIntegration");
        protected By configureImportListHeader = By.XPath("//header//*[contains(text(),'Configure Import List')]");
        protected By companyKnowledgeTab = By.Id("IdCompanyNameTab");
        protected By companyKnowledgebaseListHeader = By.XPath("//header//*[contains(text(),'Company Knowledgebase List')]");
        protected By aboutUsTab = By.Id("IdAboutUsTab");
        protected By aboutUsHeader = By.Id("divPartialAboutuUs");

        //General
        protected By generalSettingsHeader = By.XPath("//header//*[contains(text(),'General Settings')]");
        protected By dataResetCheckBox = By.Id("EnableDataReset");
        protected By enablePurgeCheckBox = By.Id("EnablePurgeArchivet");
        protected By archivePeriodDaysTxtBox = By.Id("ArchivePeriodDays");
        protected By inactiveDaysTxtBox = By.Id("InactiveDays");
        protected By notificationsWaitPeriodTxtBox = By.Id("NotificationsWaitPeriod");
        protected By updateFeatureSubmitBtn = By.Id("UpdateFeatureSubmit");
        //Security
        protected By userHeader = By.XPath("//header//*[contains(text(),'User')]");
        protected By usersTab = By.Id("IdRTabUsers");
        protected By userNameTxt = By.Id("UserName");
        protected By emailAddressTxt = By.Id("EmailAddress");
        protected By UserStatusCodeDrpdown = By.Id("UserStatusCode");
        protected By editUserBtn = By.Id("editUser");
        //D&B
        protected By d_bLicenseKeysHeader = By.XPath("//header//*[contains(text(),'D&B License Keys')]");
        protected By licenceTab = By.Id("IdLicenceTab");
        protected By identityResolutionTab = By.Id("IdIdentityResolutionTab");//Global Minimum Match Criteria
        protected By globalMinimumMatchHeader = By.XPath("//header//*[contains(text(),'Global Minimum Match Criteria')]");
        protected By dataEnrichmentTab = By.Id("IdDataEnrichmentTab");
        protected By dnBApiGroupHeader = By.XPath("//header//*[contains(text(),'DnBApi Group')]");
        protected By monitoringTab = By.Id("IdMonitoringTab");
        protected By credentialNameTag = By.XPath("//label[contains(text(),'Credential Name')][1]");
        protected By monitoringDirectPlusTab = By.Id("IdMonitoringDirectPlusTab");
        protected By registrationDetailsHeader = By.XPath("//header//*[contains(text(),'Registration Details')]");
        //ComplianceTab
        protected By complianceLicenseTab = By.Id("IdComplianceLicenseTab");
        protected By complianceSettingsHeader = By.XPath("//header//*[contains(text(),'Compliance Settings')]");
        protected By complianceAllSettingsTab = By.Id("IdComplianceAllSettingsTab");
        protected By complianceWatchListHeader = By.XPath("//header//*[contains(text(),'Compliance Watch List')]");
        public SettingsPage SelectingSettingsSubSubTabs(string SubTabName)
        {
            By subtabname = By.XPath("//a");
            By tabVerification=By.XPath("//*");
            switch (SubTabName.Trim().ToUpper().ToString())
            {
                case "GENERAL":
                    subtabname = generalTab;
                    tabVerification = generalSettingsHeader;
                    break;
                case "SECURITY":
                    subtabname = securityTab;
                    tabVerification = userHeader;
                    break;
                case "COMMON":
                    subtabname = commonTab;
                    tabVerification = countryGroupHeader;
                    break;
                case "DATA INTEGRATION":
                    subtabname = dataIntegrationTab;
                    tabVerification = configureImportListHeader;
                    break;
                case "COMPANY KNOWLEDGE BASE":
                    subtabname = companyKnowledgeTab;
                    tabVerification = companyKnowledgebaseListHeader;
                    break;
                case "ABOUT US":
                    subtabname = aboutUsTab;
                    tabVerification = aboutUsHeader;
                    break;
                case "D&B LICENSE":
                    subtabname = licenceTab;
                    tabVerification = d_bLicenseKeysHeader;
                    break;
                case "IDENTITY RESOLUTION":
                    Thread.Sleep(2600);
                    subtabname = identityResolutionTab;
                    tabVerification = globalMinimumMatchHeader;
                    break;
                case "DATA ENRICHMENT":
                    subtabname = dataEnrichmentTab;
                    Thread.Sleep(1600);
                    tabVerification = dnBApiGroupHeader;
                    break;
                case "MONITORING DIRECT 2.0":
                    subtabname = monitoringTab;
                    Thread.Sleep(2400);
                    tabVerification = credentialNameTag;
                    break;
                case "MONITORING DIRECT +":
                    subtabname = monitoringDirectPlusTab;
                    tabVerification = registrationDetailsHeader;
                    break;
                case "COMPLIANCE SETTING":
                    subtabname = complianceAllSettingsTab;
                    tabVerification = complianceSettingsHeader;
                    break;
                case "COMPLIANCE LICENSE":
                    subtabname = complianceLicenseTab;
                    tabVerification = complianceWatchListHeader;
                    break;
                default:
                    Console.WriteLine("Wrong Input");
                    break;
            }
            HelperActions.OnClick(subtabname, driver);
            Assert.True(HelperActions.ElementExists(tabVerification, driver), "Failed in validating Settings Sub Sub Tabs landing page");
            return new SettingsPage(driver);
        }
    }
}
