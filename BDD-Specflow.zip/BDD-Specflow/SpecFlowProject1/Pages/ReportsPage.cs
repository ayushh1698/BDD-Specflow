﻿using OpenQA.Selenium;

namespace Service_Portal.Pages
{
    internal class ReportsPage
    {
        private IWebDriver driver;
        public ReportsPage(IWebDriver driver) => this.driver = driver;


    }
}
