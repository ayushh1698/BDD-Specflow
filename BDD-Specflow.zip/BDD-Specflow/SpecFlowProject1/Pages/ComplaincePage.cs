﻿using OpenQA.Selenium;

namespace Service_Portal.Pages
{
    internal class ComplaincePage
    {
        private IWebDriver driver;
        public ComplaincePage(IWebDriver driver) => this.driver = driver;
    }
}
