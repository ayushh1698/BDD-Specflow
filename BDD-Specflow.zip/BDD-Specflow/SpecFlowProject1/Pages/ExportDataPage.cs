﻿using NUnit.Framework;
using OpenQA.Selenium;
using Service_Portal.Helper;

namespace Service_Portal.Pages
{
    internal class ExportDataPage
    {
        private IWebDriver driver;
        protected By companyDataTab = By.Id("IdExportDataTab");
        protected By exportOptionsHeader = By.XPath("//*[contains(text(),'Export Options')]");

        protected By monitoringNotification = By.Id("IdMonitoringExportDataTab");
        protected By monitoringNotificationsHeader = By.XPath("//*[contains(text(),'Monitoring Notifications')]");
        public ExportDataPage(IWebDriver driver) => this.driver = driver;
        public ExportDataPage SelectingExportSubTabs(string SubTabName)
        {
            By subtabname = By.XPath("//a");
            By verificationtab = By.XPath("//*");
            if (SubTabName.Trim().ToUpper() == "COMPANY")
            {
                subtabname = companyDataTab;
                verificationtab = exportOptionsHeader;
            }
            else if (SubTabName.Trim().ToUpper() == "MONITORING")
            {
                subtabname = monitoringNotification;
                verificationtab= monitoringNotificationsHeader;
            }
            HelperActions.OnClick(subtabname, driver);
            Assert.IsTrue(HelperActions.ElementExists(verificationtab, driver), "failed in validating Export subtab landing pages");
            return new ExportDataPage(driver);

        }
    }
}
