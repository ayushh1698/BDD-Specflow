﻿using OpenQA.Selenium;

namespace Service_Portal.Pages
{
    internal class ImportDataPage
    {
        private IWebDriver driver;
        public ImportDataPage(IWebDriver driver) => this.driver = driver;
    }
}
