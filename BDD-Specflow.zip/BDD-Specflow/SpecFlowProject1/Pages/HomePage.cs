﻿using AventStack.ExtentReports.Gherkin.Model;
using Microsoft.AspNetCore.Routing.Matching;
using NUnit.Framework;
using OpenQA.Selenium;
using Service_Portal.Helper;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Service_Portal.Pages
{
    internal class HomePage
    {
        private IWebDriver driver;
        public HomePage(IWebDriver driver) => this.driver = driver;

        protected By userName = By.XPath("//span[@class='lblUserName']");
        protected By settingTab = By.XPath("//a[@href='#']/span[@class='menu-item-parent'][contains(text(), 'Settings')]");
        protected By dashboardTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Dashboard')]");
        protected By importDataTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Import Data')]");
        protected By exportDataTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Export Data')]");
        protected By dataStewardshipTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Data Stewardship ')]");
        protected By prospectingTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Prospecting')]");
        protected By complianceTab = By.XPath("//a[@href='#']/span[@class='menu-item-parent'][contains(text(), 'Compliance')]");
        protected By reportsTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Reports')]");
        //ImportTab
        protected By importDataStatusHeader = By.XPath("//header//*[contains(text(),'Import Data Status')]");
        
        //ReportsTab
        protected By rep_BaseReportsTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Base Reports')]");
        protected By dataQueueDashboardHeader = By.XPath("//*[contains(text(),'Data Queue Dashboard')]");
        protected By rep_InvestigationReportTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Investigation Report')]");
        protected By D_BiResearchInvestigationHeader = By.XPath("//header//*[contains(text(),'D&B iResearch Investigation')]");
        protected By rep_MetricDashboardTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Metrics Dashboard')]");       
        protected By powerBiReportTable = By.XPath("//div[@class='imgmaindivMatchbook']");

        //Compliance
        protected By com_ComplianceListTab = By.XPath("//a[@href='/ComplianceList']/span[@class='menu-item-parent'][contains(text(), 'Compliance List')]");
        protected By complianceDataHeader = By.XPath("//*[contains(text(),'Compliance Data')]");
        protected By com_AdjudicationTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Adjudication')]");
        protected By adjudicationListHeader = By.XPath("//*[contains(text(),'Adjudication List')]");

        //Prospecting
        protected By pro_SearchDataTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Search Data')]");
        protected By searchDataHeader = By.XPath("//*[contains(text(),'Search Data')]");
        protected By pro_BuildAListTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Build A List')]");
        protected By searchResultsHeader = By.XPath("//*[contains(text(),'Search Results')]");

        //Data Stewardship
        protected By ds_reviewMatchCandidatesTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Review Match Candidates')]");
        protected By reviewMatchesHeader = By.XPath("//header//*[contains(text(), 'Review Matches')]");
        protected By ds_lowConfidenceTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Low Confidence')]");
        protected By filteredCandidatesHeader = By.XPath("//header//*[contains(text(), 'Filter Match Candidates on the Current Page')]");
        protected By ds_noMatchTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'No Match')]");
        protected By noMatchHeader = By.XPath("//header//*[contains(text(), 'No Match')]");
        protected By ds_previewMatchedDataTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Preview Matched Data')]");
        protected By previewMatchedDataHeader = By.XPath("//header//*[contains(text(), 'Preview Matched Data')]");

        //Settings
        protected By set_PortalTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'Portal')]");
        protected By set_D_BTab = By.XPath("//span[@class='menu-item-parent'][contains(text(), 'D&B')]");
        protected By set_ComplianceTab = By.XPath("//*[@href='/Compliance']/span[@class='menu-item-parent'][contains(text(), 'Compliance')]");
        protected By serverError = By.XPath("//*[@src='/Images/500-error.png']");

        public HomePage ValidationOfEachTab()
        {
            {
                By[] Tabs = new By[] { settingTab, dashboardTab, importDataTab, exportDataTab, dataStewardshipTab, prospectingTab, complianceTab, reportsTab };
                foreach (By tabName in Tabs)
                {
                    Assert.True(HelperActions.ElementExists(tabName, driver),"failed in validting Home page tabs");

                }
                return new HomePage(driver);
            }
        }
        public HomePage ClickingTab(string TabName)
        {
            var tabname = dashboardTab;
            if (TabName.ToUpper().Contains("DASHBOARD"))
            {
                tabname = dashboardTab;
            }
            if (TabName.ToUpper().Contains("IMPORT"))
            {
                tabname = importDataTab;
            }
            if (TabName.ToUpper().Contains("EXPORT"))
            {
                tabname = exportDataTab;
            }
            if (TabName.ToUpper().Contains("DATASTEWARD"))
            {
                tabname = dataStewardshipTab;
            }
            if (TabName.ToUpper().Contains("COMPIANCE"))
            {
                tabname = complianceTab;
            }
            if (TabName.ToUpper().Contains("PROSPECTING"))
            {
                tabname = prospectingTab;
            }
            if (TabName.ToUpper().Contains("REPORT"))
            {
                tabname = reportsTab;
            }
            HelperActions.OnClick(tabname, driver);
            return new HomePage(driver);

        }
        public SettingsPage SelectingSettingSubTab(string TabName)
        {
            By subtabname = set_D_BTab;
            switch (TabName.Trim().ToUpper())
            {
                case "PORTAL":
                    subtabname = set_PortalTab;
                    break;
                case "COMPLAINCE":
                    subtabname = set_ComplianceTab;
                    break;
                case "D&B":
                    subtabname = set_D_BTab;
                    break;
                default:
                    Console.WriteLine("Wrong Input");
                    break;
            }
            HelperActions.OnClick(subtabname, driver);
            return new SettingsPage(driver);
        }
        public ReportsPage SelectingReportsSubTab(string TabName)
        {
            By subtabname = rep_MetricDashboardTab;
            By tabVerification = By.XPath("//");
            switch (TabName.Trim().ToUpper())
            {
                case "BASE REPORTS":
                    subtabname = rep_BaseReportsTab;
                    tabVerification = dataQueueDashboardHeader;
                    break;
                case "INVESTIGATION REPORT":
                    subtabname = rep_InvestigationReportTab;
                    tabVerification = D_BiResearchInvestigationHeader;
                    break;
                case "METRICS DASHBOARD":
                    subtabname = rep_MetricDashboardTab;
                    tabVerification = powerBiReportTable;
                    break;
                default:
                    Console.WriteLine("Wrong Input");
                    break;
            }
            HelperActions.OnClick(subtabname, driver);
            Assert.True(HelperActions.ElementExists(tabVerification, driver),"Report verification subpage not visible");
            Assert.False(HelperActions.ValidatingInternalServerPage(serverError,driver),"Getting Internal Server Error on page");
            return new ReportsPage(driver);
        }
        public ComplaincePage SelectingComplainceSubTab(string TabName)
        {
            By subtabname = com_ComplianceListTab;
            By tabVerification = By.XPath("//");
            switch (TabName.Trim().ToUpper())
            {
                case "COMPLIANCE LIST":
                    subtabname = com_ComplianceListTab;
                    tabVerification = complianceDataHeader;
                    break;
                case "ADJUDICATION":
                    subtabname = com_AdjudicationTab;
                    tabVerification = adjudicationListHeader;
                    break;
                default:
                    Console.WriteLine("Wrong Input");
                    break;
            }
            HelperActions.OnClick(subtabname, driver);
            Assert.True(HelperActions.ElementExists(tabVerification, driver));
            Assert.False(HelperActions.ValidatingInternalServerPage(serverError, driver), "Getting Internal Server Error on page");
            return new ComplaincePage(driver);
        }
        public ProspectingPage SelectingProspectingSubTab(string TabName)
        {
            By subtabname = pro_SearchDataTab;
            By tabVerification = By.XPath("//");
            switch (TabName.Trim().ToUpper())
            {
                case "SEARCH DATA":
                    subtabname = pro_SearchDataTab;
                    tabVerification = searchDataHeader;
                    break;
                case "BUILD A LIST":
                    subtabname = pro_BuildAListTab;
                    tabVerification = searchResultsHeader;
                    break;
                default:
                    Console.WriteLine("Wrong Input");
                    break;
            }
            HelperActions.OnClick(subtabname, driver);
            Assert.True(HelperActions.ElementExists(tabVerification, driver));
            Assert.False(HelperActions.ValidatingInternalServerPage(serverError, driver), "Getting Internal Server Error on page");
            return new ProspectingPage(driver);
        }
        public HomePage ValidatingImportPage()
        {
            Assert.True(HelperActions.ElementExists(importDataStatusHeader,driver));
            return new HomePage(driver);
        }
        public DataStewardshipPage SelectingDataStewardShipSubTab(string TabName)
        {
            By subtabname = ds_previewMatchedDataTab;
            By tabVerification = By.XPath("//");
            switch (TabName.Trim().ToUpper())
            {
                case "REVIEW MATCH CANDIDATES":
                    subtabname = ds_reviewMatchCandidatesTab;
                    tabVerification = reviewMatchesHeader;
                    break;
                case "LOW CONFIDENCE":
                    subtabname = ds_lowConfidenceTab;
                    tabVerification = filteredCandidatesHeader;
                    break;
                case "NO MATCH":
                    subtabname = ds_noMatchTab;
                    tabVerification = noMatchHeader;
                    break;
                case "PREVIEW MATCHED DATA":
                    subtabname = ds_previewMatchedDataTab;
                    tabVerification = previewMatchedDataHeader;
                    break;
                default:
                    Console.WriteLine("Wrong Input");
                    break;
            }
            HelperActions.OnClick(subtabname, driver);
            Assert.True(HelperActions.ElementExists(tabVerification, driver));
            Assert.False(HelperActions.ValidatingInternalServerPage(serverError, driver), "Getting Internal Server Error on page");
            return new DataStewardshipPage(driver);
        }
    }
}
