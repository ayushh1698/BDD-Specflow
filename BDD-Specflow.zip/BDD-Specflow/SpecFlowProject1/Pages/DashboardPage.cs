﻿using NUnit.Framework;
using OpenQA.Selenium;
using Service_Portal.Helper;

namespace Service_Portal.Pages
{
    internal class DashboardPage
    {
        private IWebDriver driver;
        public DashboardPage(IWebDriver driver) => this.driver = driver;
        protected By activeDataStats = By.XPath("//span/*[contains(text(),'Active Data Queue Statistics')]");

        protected By backgroundProcessStats = By.XPath("//span/*[contains(text(),'Background Process Statistics')]");
        protected By matchCandidatesStats = By.XPath("//span/*[contains(text(),'Low Confidence Match Candidate Statistics')]");
        protected By dataStewardshipStats = By.XPath("//span/*[contains(text(),'Data Stewardship Statistics')]");
        protected By apiUsageStats = By.XPath("//span/*[contains(text(),'API Usage Statistics')]");
        public DashboardPage ValidatingRespectiveTables()
        {
            By[] Tabs = new By[] { activeDataStats, backgroundProcessStats, matchCandidatesStats, dataStewardshipStats, apiUsageStats };

            foreach (By tabname in Tabs)
                Assert.IsTrue(HelperActions.ElementExists(activeDataStats, driver), "failed in validating dashboard tables");
            return new DashboardPage(driver);
        }
    }
}
