﻿using OpenQA.Selenium;

namespace Service_Portal.Pages
{
    internal class DataStewardshipPage
    {
        private IWebDriver driver;
        public DataStewardshipPage(IWebDriver driver) => this.driver = driver;
    }
}
