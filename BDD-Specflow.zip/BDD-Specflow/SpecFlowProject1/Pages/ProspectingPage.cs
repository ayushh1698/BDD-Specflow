﻿using OpenQA.Selenium;

namespace Service_Portal.Pages
{
    internal class ProspectingPage
    {
        private IWebDriver driver;
        public ProspectingPage(IWebDriver driver) => this.driver = driver;
    }
}
