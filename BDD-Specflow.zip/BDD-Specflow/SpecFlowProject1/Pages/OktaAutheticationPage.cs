﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Service_Portal.Helper;

namespace Service_Portal.Pages
{
    public class OktaAutheticationPage
    {
        private IWebDriver driver;
        public OktaAutheticationPage(IWebDriver driver) => this.driver = driver;

        protected By usernameTxtbox = By.XPath("//input[@type='text']");
        protected By pwdTxtbox = By.XPath("//input[@type='password']");
        protected By submitBtn = By.XPath("//input[@type='submit']");
        protected By oktaHeader = By.CssSelector("div[class='okta-sign-in-header auth-header']");
        public void SigninginOkta(string username, String pwd)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(15));
                wait.Until(d => driver.FindElement(submitBtn).Enabled);
                driver.FindElement(usernameTxtbox).SendKeys(username);
                driver.FindElement(pwdTxtbox).SendKeys(pwd);
                HelperActions.OnClick(submitBtn, driver);
            }
            catch (NoSuchElementException ex)
            {
                var mesg = ex.Message;
            }

        }

    }
}
