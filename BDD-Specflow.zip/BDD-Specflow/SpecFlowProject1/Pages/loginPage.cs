﻿using NUnit.Framework;
using OpenQA.Selenium;
using Service_Portal.Helper;

namespace Service_Portal.Pages
{
    public class LoginPage
    {
        private IWebDriver driver;
        public LoginPage(IWebDriver driver) => this.driver = driver;

        protected By emailTxtbox = By.XPath("//div[@class='login-page']//input[@id='EmailAddressInput']");
        protected By oktaOptionBtn = By.XPath("//*[contains(text(),'Sign in with Okta')]");
        public LoginPage ValidatingLoginPage()
        {
            Assert.True(HelperActions.ElementExists(emailTxtbox, driver),"Failed in validating login page");
            return new LoginPage(driver);
        }
        public OktaAutheticationPage SelectOktaLogin()
        {
            HelperActions.OnClick(oktaOptionBtn, driver);
            return new OktaAutheticationPage(driver);
        }
    }

}
