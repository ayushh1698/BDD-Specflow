﻿using Microsoft.Extensions.Configuration;

namespace Service_Portal.Utility
{
    public class Config
    {
        public string? TRAINING_URL { get; set; }
        public string? UAT_URL { get; set; }
        public string? PROD_URL { get; set; }
        public string? QA_URL { get; set; }
        public string? DEV_URL { get; set; }
        public string? USER_ID { get; set; }
        public string? PWD { get; set; }
        // any other config you need

    }

    public static class ConfigProvider
    {

        public static Config Config;

        static ConfigProvider()
        {
            // Build config from various sources
            var configRoot = new ConfigurationBuilder()
                .AddJsonFile("testConfig.json")
                .AddEnvironmentVariables()
                .Build();

            // Bind config to new config object
            Config = new Config();

            // Bind params from testParams.json
            configRoot.Bind(Config);
        }

    }

}
