﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Configuration;
using OpenQA.Selenium;

namespace Service_Portal.Utility
{
    public class ExtendReport
    {
        public static ExtentReports _extentReports;
        public static ExtentTest _feature;
        public static ExtentTest _scenario;
        public static ExtentTest _stepLogger;
        public static ExtentTest scenario;
        public static ExtentTest stepLogger;
        public static ExtentTest _testLog;

        public static String dir = AppDomain.CurrentDomain.BaseDirectory;
        public static String testResultPath = dir.Replace("bin\\Debug\\net7.0", "TestResults");

        public static void ExtentReportInit(String path)
        {
            testResultPath=testResultPath.Replace("TestResults", path);
            var htmlReporter = new ExtentHtmlReporter(testResultPath);
            htmlReporter.Config.ReportName = "Automation Status "+ path;
            htmlReporter.Config.DocumentTitle = "Automation Status "+ path;
            htmlReporter.Config.Theme = Theme.Standard;
            htmlReporter.Start();

            _extentReports = new ExtentReports();
            _extentReports.AttachReporter(htmlReporter);
            _extentReports.AddSystemInfo("Application", "MatchBook AI");
            _extentReports.AddSystemInfo("Browser", "Chrome");
            _extentReports.AddSystemInfo("OS", "Windows");
        }

        public static void ExtentReportTearDown()
        {
            _extentReports.Flush();
        }

        public string addScreenshot(IWebDriver driver, ScenarioContext scenarioContext)
        {
            ITakesScreenshot takesScreenshot = (ITakesScreenshot)driver;
            Screenshot screenshot = takesScreenshot.GetScreenshot();
            string screenshotLocation = Path.Combine(testResultPath, scenarioContext.ScenarioInfo.Title + ".png");
            screenshot.SaveAsFile(screenshotLocation, ScreenshotImageFormat.Png);
            return screenshotLocation;
        }
        public static ExtentTest CreateStepLogger()
        {
            stepLogger = _scenario.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text);
            return stepLogger;
        }

        public static void Pass(string msgPass, MediaEntityModelProvider? provider = null)
        {
            stepLogger = _scenario.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text);
            stepLogger.Pass(msgPass, provider);
        }

        public static void Pass(Exception ex, MediaEntityModelProvider? provider = null)
        {
            CreateStepLogger();
            stepLogger.Pass(ex, provider);
        }

        public static void Fail(string msgPass, MediaEntityModelProvider? provider = null)
        {
            CreateStepLogger();
            stepLogger.Fail(msgPass, provider);
        }

        public static void Fail(Exception ex, MediaEntityModelProvider? provider = null)
        {
            CreateStepLogger();
            stepLogger.Fail(ex, provider);
        }

        public static void Fail(string msgpass, bool failCondition, MediaEntityModelProvider? provider = null)
        {
            CreateStepLogger();
            stepLogger.Fail(msgpass, provider);
        }

    }
}
